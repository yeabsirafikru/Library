<?php
require_once 'includes/config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $userRole = getUserRole();
    redirect(getDashboardByRole($userRole));
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    try {
        // Check if user exists with the given username
        $stmt = $db->prepare("SELECT u.*, ur.role_name FROM users u 
                             JOIN user_roles ur ON u.role_id = ur.id 
                             WHERE u.username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role_id'] = $user['role_id'];
            $_SESSION['role_name'] = $user['role_name'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['last_name'] = $user['last_name'];
            
            // Update last active timestamp
            $updateStmt = $db->prepare("UPDATE users SET last_active = CURRENT_TIMESTAMP WHERE id = ?");
            $updateStmt->execute([$user['id']]);
            
            // Redirect based on user role
            redirect(getDashboardByRole($user['role_id']));
        } else {
            $error = 'Invalid username or password';
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - PharmaManage</title>
<link rel="stylesheet" href="assets/css/base/reset.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/base/variables.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/alerts.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/badges.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/cards.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/forms.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/header.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/modals.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/search.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/tables.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/buttons.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/layouts/container.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/pages/id.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/utilities/animations.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/utilities/responsive.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/utilities/dark-mode.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/utilities/typography.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/utilities/utilities.css" type="text/css" media="all" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="assets/js/index.js" charset="utf-8" defer></script>
<script src="assets/js/modal.js" charset="utf-8" defer></script>
<script src="assets/js/form.js" charset="utf-8" defer></script>
</head>
<body>
  <div class="auth-page">
    
    <div class="auth-container">
        <div class="auth-card">
                        <button class="theme-toggle theme-register" id="mobileThemeToggle" style="background: var(--dark-1);">
            <i class="fas fa-moon"></i>
            <span class="theme-text">Dark Mode</span>
        </button>
            <div class="auth-header">
                <div class="auth-brand">
                    <i class="fas fa-book-open brand-icon"></i>
                    <span class="brand-text">Sabian</span>
                </div>
                <h1 class="auth-title">Welcome Back</h1>
                <p class="auth-subtitle">Sign in to your account</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="auth-form">
              <div class="form-row">
                
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <div class="input-with-icon">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" 
                               class="input" 
                               id="username" 
                               name="username" 
                               required 
                               placeholder="Enter your username"
                               value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" 
                               class="input" 
                               id="password" 
                               name="password" 
                               required 
                               placeholder="Enter your password">
                        <button type="button" class="input-action" id="togglePassword">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
              </div>
                
                <div class="block-buttom">
                  
                <button type="submit" class="btn btn-primary btn-md">
                    <i class="fas fa-sign-in-alt"></i>
                    Sign In
                </button>
                </div>
            </form>

            <div class="auth-footer">
                <p class="auth-link-text">Don't have an account? <a href="/register.php" class="auth-link">Register here</a></p>
                
            </div>
        </div>
    </div>
  </div>

</body>
</html>