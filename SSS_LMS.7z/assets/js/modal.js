// Enhanced Search Functionality with Better Error Handling
document.addEventListener('DOMContentLoaded', function() {
    const searchInputs = document.querySelectorAll('.search-input');
    let searchTimeout;

    // Initialize search for each input
    searchInputs.forEach(input => {
        const searchContainer = input.closest('.search-container');
        const resultsContainer = createResultsContainer(searchContainer);
        
        setupSearchEvents(input, resultsContainer);
    });

    // Close results when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.search-container')) {
            hideAllResults();
        }
    });
});

function createResultsContainer(searchContainer) {
    const resultsContainer = document.createElement('div');
    resultsContainer.className = 'search-results';
    resultsContainer.style.display = 'none';
    searchContainer.appendChild(resultsContainer);
    return resultsContainer;
}

function setupSearchEvents(input, resultsContainer) {
    let searchTimeout;

    // Input event with debouncing
    input.addEventListener('input', function(e) {
        const query = e.target.value.trim();
        clearTimeout(searchTimeout);
        
        if (query.length === 0) {
            hideResults(resultsContainer);
            return;
        }

        if (query.length < 2) {
            showMessage(resultsContainer, 'Type at least 2 characters...');
            return;
        }

        showLoading(resultsContainer);
        
        searchTimeout = setTimeout(() => {
            performSearch(query, resultsContainer);
        }, 300);
    });

    // Keyboard navigation
    input.addEventListener('keydown', function(e) {
        const results = resultsContainer.querySelectorAll('.search-result-item');
        
        if (e.key === 'ArrowDown' && results.length > 0) {
            e.preventDefault();
            results[0].focus();
        } else if (e.key === 'Escape') {
            hideResults(resultsContainer);
            input.blur();
        }
    });

    // Show results on focus if we have a query
    input.addEventListener('focus', function() {
        const query = input.value.trim();
        if (query.length >= 2 && resultsContainer.children.length > 0) {
            showResults(resultsContainer);
        }
    });
}

function performSearch(query, container) {
    console.log('Searching for:', query);
    
    // Get the correct path for search.php
    const basePath = window.location.pathname.split('/').slice(0, -1).join('/') || '';
    const searchUrl = `${basePath}/search.php?query=${encodeURIComponent(query)}`;
    
    console.log('Search URL:', searchUrl);
    
    fetch(searchUrl)
        .then(response => {
            console.log('Response status:', response.status);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                throw new Error('Server returned non-JSON response');
            }
            
            return response.json();
        })
        .then(data => {
            console.log('Search response:', data);
            
            if (data.success) {
                displayResults(container, data.results, query);
            } else {
                showError(container, data.error || 'Search failed on server');
            }
        })
        .catch(error => {
            console.error('Search fetch error:', error);
            showError(container, `Search unavailable: ${error.message}`);
        });
}

function displayResults(container, results, query) {
    if (results.length === 0) {
        container.innerHTML = `
            <div class="search-no-results">
                <i class="fas fa-search"></i>
                <div class="no-results-content">
                    <p class="no-results-title">No results found</p>
                    <p class="no-results-subtitle">Try different keywords</p>
                </div>
            </div>
        `;
    } else {
        container.innerHTML = results.map(result => {
            const isBook = result.type === 'book';
            const itemClass = 'search-result-item';
            
            return `
                <div class="${itemClass}" data-type="${result.type}" data-id="${result.id}">
                    <div class="result-avatar" style="background-color: ${result.avatar_color}">
                        <span class="avatar-text">${result.avatar_text}</span>
                    </div>
                    <div class="result-info">
                        <div class="result-name">${highlightMatch(result.name, query)}</div>
                        <div class="result-details">
                            ${isBook ? 
                                `<div class="result-meta">
                                    <span class="result-category">${escapeHtml(result.category)}</span>
                                    <span class="result-author">by ${escapeHtml(result.author)}</span>
                                </div>
                                <div class="result-status ${result.available ? 'available' : 'unavailable'}">
                                    <i class="fas ${result.available ? 'fa-check-circle' : 'fa-times-circle'}"></i>
                                    ${result.available ? 'Available' : 'Unavailable'}
                                </div>` :
                                `<div class="result-meta">
                                    <span class="result-role ${result.role.toLowerCase()}">
                                        <i class="${result.icon}"></i>
                                        ${result.role}
                                    </span>
                                </div>
                                <div class="result-status available">
                                    <i class="fas fa-circle"></i>
                                    Active
                                </div>`
                            }
                        </div>
                    </div>
                    <div class="result-action">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            `;
        }).join('');

        // Add event listeners to results
        const resultItems = container.querySelectorAll('.search-result-item');
        resultItems.forEach((item, index) => {
            const result = results[index];
            item.style.cursor = 'pointer';
            item.addEventListener('click', () => {
                window.location.href = result.url;
            });
            
            item.addEventListener('keydown', (e) => {
                handleResultNavigation(e, index, resultItems, container);
            });
            
            item.setAttribute('tabindex', '0');
            
            // Hover effects
            item.addEventListener('mouseenter', function() {
                this.style.backgroundColor = 'var(--bg-hover)';
            });
            item.addEventListener('mouseleave', function() {
                this.style.backgroundColor = '';
            });
        });
    }
    showResults(container);
}

// ... keep the rest of the helper functions the same as before ...
function handleResultNavigation(e, index, items, container) {
    const input = container.previousElementSibling;
    
    switch(e.key) {
        case 'ArrowDown':
            e.preventDefault();
            if (items[index + 1]) {
                items[index + 1].focus();
            }
            break;
        case 'ArrowUp':
            e.preventDefault();
            if (index > 0) {
                items[index - 1].focus();
            } else {
                input.focus();
            }
            break;
        case 'Enter':
            e.preventDefault();
            items[index].click();
            break;
        case 'Escape':
            hideResults(container);
            input.focus();
            break;
    }
}

function highlightMatch(text, query) {
    if (!text || !query) return escapeHtml(text);
    const regex = new RegExp(`(${escapeRegex(query)})`, 'gi');
    return escapeHtml(text).replace(regex, '<mark>$1</mark>');
}

function showLoading(container) {
    container.innerHTML = `
        <div class="search-loading">
            <i class="fas fa-spinner fa-spin"></i>
            <span>Searching...</span>
        </div>
    `;
    showResults(container);
}

function showMessage(container, message) {
    container.innerHTML = `
        <div class="search-no-results">
            <i class="fas fa-info-circle"></i>
            <span>${message}</span>
        </div>
    `;
    showResults(container);
}

function showError(container, message) {
    container.innerHTML = `
        <div class="search-no-results">
            <i class="fas fa-exclamation-triangle"></i>
            <span>${message}</span>
        </div>
    `;
    showResults(container);
}

function showResults(container) {
    container.style.display = 'block';
    const searchContainer = container.closest('.search-container');
    if (searchContainer) {
        const input = searchContainer.querySelector('.search-input');
        if (input) {
            container.style.width = input.offsetWidth + 'px';
        }
    }
}

function hideResults(container) {
    container.style.display = 'none';
}

function hideAllResults() {
    document.querySelectorAll('.search-results').forEach(hideResults);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}