const modalOverlay = document.getElementById('modalOverlay');
const openModalBtn = document.getElementById('openModal');
const closeModalBtn = document.getElementById('closeModal');
const cancelModalBtn = document.getElementById('cancelModal');

const droplinks = document.querySelectorAll('.sub-menu-link');

openModalBtn.addEventListener('click', () => {
    modalOverlay.classList.add('active');
});

closeModalBtn.addEventListener('click', () => {
    modalOverlay.classList.remove('active');
});

cancelModalBtn.addEventListener('click', () => {
    modalOverlay.classList.remove('active');
});

droplinks.forEach(link => {
    link.addEventListener('click', () => {
        modalOverlay.classList.remove('active');
    });
});

modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) {
        modalOverlay.classList.remove('active');
    }
});