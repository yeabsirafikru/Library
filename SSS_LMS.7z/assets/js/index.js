// Theme Toggle
const themeToggles = document.querySelectorAll('.theme-toggle');

function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.body.setAttribute('data-theme', savedTheme);
    updateAllThemeElements(savedTheme);
}

function updateAllThemeElements(theme) {
    const isDark = theme === 'dark';
    
    themeToggles.forEach(toggle => {
        // Update icon
        toggle.querySelector('i').className = isDark 
            ? 'fas fa-sun' 
            : 'fas fa-moon';
        
        // Update text
        const themeText = toggle.querySelector('.theme-text');
        if (themeText) {
            themeText.textContent = isDark ? 'Light Mode' : 'Dark Mode';
        }
    });
}

function toggleTheme() {
    const currentTheme = document.body.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.body.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateAllThemeElements(newTheme);
}

// Initialize theme when page loads
document.addEventListener('DOMContentLoaded', initTheme);

// Add event listeners to all theme toggle buttons
themeToggles.forEach(toggle => {
    toggle.addEventListener('click', toggleTheme);
});

// Mobile Search Toggle
const searchToggle = document.getElementById('searchToggle');
const searchExpanded = document.getElementById('searchExpanded');
const searchClose = document.getElementById('searchClose');
const mobileSearchInput = document.getElementById('mobileSearchInput');

searchToggle.addEventListener('click', () => {
    searchExpanded.classList.add('active');
    mobileSearchInput.focus();
});

searchClose.addEventListener('click', () => {
    searchExpanded.classList.remove('active');
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && searchExpanded.classList.contains('active')) {
        searchExpanded.classList.remove('active');
    }
});

// Mobile Menu Toggle
const menuToggle = document.getElementById('menuToggle');
const mobileMenu = document.getElementById('mobileMenu');
const overlay = document.getElementById('overlay');

menuToggle.addEventListener('click', () => {
    mobileMenu.classList.toggle('active');
    overlay.classList.toggle('active');
    document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
});

overlay.addEventListener('click', () => {
    searchExpanded.classList.remove('active');
    mobileMenu.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
});

const mobileLinks = document.querySelectorAll('.mobile-nav-link');
mobileLinks.forEach(link => {
    link.addEventListener('click', () => {
        mobileMenu.classList.remove('active');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
    });
});

// User Menu functionality - Desktop
const subMenu = document.getElementById('subMenu');
const userAvatar = document.getElementById('userAvatar');

function openMenu() {
    subMenu.classList.add('open-menu');
}

function closeMenu() {
    subMenu.classList.remove('open-menu');
}

// Desktop hover events
if (userAvatar) {
    userAvatar.addEventListener('mouseenter', openMenu);
    userAvatar.addEventListener('mouseleave', closeMenu);
}

if (subMenu) {
    subMenu.addEventListener('mouseenter', openMenu);
    subMenu.addEventListener('mouseleave', closeMenu);
}

// Close menu on window resize
window.addEventListener('resize', function() {
    if (window.innerWidth < 768) {
        closeMenu();
    }
});

// Enhanced tooltip functionality (optional)
function initNavigationTooltips() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        // Create tooltip if it doesn't exist
        if (!link.querySelector('.tooltip')) {
            const tooltipText = link.querySelector('span').textContent;
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = tooltipText;
            link.appendChild(tooltip);
        }
        
        // Add touch events for mobile
        link.addEventListener('touchstart', function(e) {
            if (window.innerWidth < 992) {
                e.preventDefault();
                const tooltip = this.querySelector('.tooltip');
                tooltip.style.opacity = '1';
                tooltip.style.visibility = 'visible';
                
                // Hide tooltip after delay
                setTimeout(() => {
                    tooltip.style.opacity = '0';
                    tooltip.style.visibility = 'hidden';
                }, 2000);
            }
        });
    });
}

// Initialize tooltips when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initNavigationTooltips();
});

const revealElements = document.querySelectorAll("[data-reveal]");

const revealElementOnScroll = function () {
  for (let i = 0, len = revealElements.length; i < len; i++) {
    const isElementInsideWindow = revealElements[i].getBoundingClientRect().top < window.innerHeight / 1.1;

    if (isElementInsideWindow) {
      revealElements[i].classList.add("revealed");
    }
  }
}

window.addEventListener("scroll", revealElementOnScroll);

window.addEventListener("load", revealElementOnScroll);