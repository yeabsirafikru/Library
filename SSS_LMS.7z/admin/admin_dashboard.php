<!-- In your pages, use this structure: -->
<body>
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>
    
    <main class="main-content">
        <!-- Your page content here -->
        <div class="container">
            <h1 class="page-title">Dashboard Overview</h1>
            <div class="card">
                Welcome to your dashboard! Use the menu to navigate, toggle the sidebar, 
                or switch between light and dark themes to personalize your experience.
            </div>
        </div>
    </main>
</body>