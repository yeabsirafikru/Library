<?php
// Enable strict error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set headers FIRST - before any output
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=utf-8');

// Prevent any output before JSON
ob_start();

try {
    // Include config with absolute path
    $config_path = __DIR__ . '../includes/config.php';
    if (!file_exists($config_path)) {
        throw new Exception('Config file not found at: ' . $config_path);
    }
    
    require_once $config_path;
    
    // Check if query parameter exists
    if (!isset($_GET['query']) || empty(trim($_GET['query']))) {
        throw new Exception('Search query is required');
    }

    $query = trim($_GET['query']);
    
    // Log the search request for debugging
    error_log("Search request received: " . $query);
    
    $results = [];

    // Determine user role
    $user_role = 'guest';
    $user_id = null;
    
    if (isLoggedIn()) {
        $role_map = [
            ROLE_ADMIN => 'admin',
            ROLE_LIBRARIAN => 'librarian', 
            ROLE_TEACHER => 'teacher',
            ROLE_STUDENT => 'student',
            ROLE_REGULAR => 'regular'
        ];
        $user_role = $role_map[getUserRole()] ?? 'regular';
        $user_id = $_SESSION['user_id'];
    }
    
    $searchTerm = "%$query%";
    
    // Search books (all users)
    $bookStmt = $db->prepare("
        SELECT 
            id, title, author, isbn, 'book' as type,
            access_type, available_copies, total_copies
        FROM books 
        WHERE (title LIKE ? OR author LIKE ? OR isbn LIKE ?)
        AND status = 'active'
        LIMIT 5
    ");
    
    $bookStmt->execute([$searchTerm, $searchTerm, $searchTerm]);
    $bookResults = $bookStmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($bookResults as &$book) {
        $book['icon'] = 'fas fa-book';
        $book['url'] = 'book_details.php?id=' . $book['id'];
        $book['badge'] = $book['access_type'];
        $book['available'] = $book['available_copies'] > 0;
        $book['name'] = $book['title'];
        $book['category'] = 'Book';
        $book['role'] = 'Book';
        $book['avatar_text'] = getInitials($book['title']);
        $book['avatar_color'] = getColorFromText($book['title']);
        $book['can_access'] = true;
    }
    
    // Search users (logged-in users only) - Simplified for testing
    $userResults = [];
    if ($user_role !== 'guest') {
        $userStmt = $db->prepare("
            SELECT 
                u.id, u.username, u.first_name, u.last_name,
                ur.role_name as role
            FROM users u 
            JOIN user_roles ur ON u.role_id = ur.id
            WHERE (u.first_name LIKE ? OR u.last_name LIKE ? OR u.username LIKE ?)
            AND u.membership_status = 'active'
            LIMIT 3
        ");
        $userStmt->execute([$searchTerm, $searchTerm, $searchTerm]);
        $userResults = $userStmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($userResults as &$user) {
            $user['name'] = trim($user['first_name'] . ' ' . $user['last_name']) ?: $user['username'];
            $user['icon'] = getRoleIcon($user['role']);
            $user['url'] = 'user_preview.php?id=' . $user['id'];
            $user['type'] = 'user';
            $user['badge'] = $user['role'];
            $user['author'] = 'User';
            $user['category'] = 'User';
            $user['available'] = true;
            $user['avatar_text'] = getInitials($user['name']);
            $user['avatar_color'] = getColorFromText($user['name']);
            $user['can_access'] = true;
        }
    }
    
    // Combine results
    $results = array_merge($bookResults, $userResults);
    
    // Clear any output buffer
    ob_clean();
    
    error_log("Search completed: " . count($results) . " results found");
    
    echo json_encode([
        'success' => true,
        'query' => $query,
        'results' => $results,
        'total' => count($results),
        'user_role' => $user_role,
        'debug' => [
            'books_found' => count($bookResults),
            'users_found' => count($userResults)
        ]
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    // Clear any output buffer
    ob_clean();
    
    error_log("Search error: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Search failed: ' . $e->getMessage(),
        'debug' => [
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]
    ], JSON_UNESCAPED_UNICODE);
}

function getRoleIcon($role) {
    $icons = [
        'admin' => 'fas fa-crown',
        'librarian' => 'fas fa-book-reader',
        'teacher' => 'fas fa-chalkboard-teacher',
        'student' => 'fas fa-graduation-cap',
        'regular' => 'fas fa-user'
    ];
    return $icons[$role] ?? 'fas fa-user';
}

function getInitials($text) {
    $words = preg_split('/\s+/', $text);
    $initials = '';
    
    if (count($words) >= 2) {
        $initials = strtoupper(substr($words[0], 0, 1) . substr($words[count($words)-1], 0, 1));
    } else {
        $initials = strtoupper(substr($text, 0, 2));
    }
    
    return $initials;
}

function getColorFromText($text) {
    $colors = [
        '#4f46e5', '#7c3aed', '#dc2626', '#ea580c', '#d97706',
        '#059669', '#0d9488', '#0891b2', '#2563eb', '#4338ca'
    ];
    
    $hash = 0;
    for ($i = 0; $i < strlen($text); $i++) {
        $hash = ord($text[$i]) + (($hash << 5) - $hash);
    }
    
    $index = abs($hash) % count($colors);
    return $colors[$index];
}
?>