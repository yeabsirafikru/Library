<?php
// test_search.php - Simple test for search functionality
require_once 'config.php';

// Test database connection
try {
    $testStmt = $db->query("SELECT COUNT(*) as count FROM books");
    $result = $testStmt->fetch(PDO::FETCH_ASSOC);
    echo "Database connection OK. Books in database: " . $result['count'] . "<br>";
} catch (Exception $e) {
    die("Database error: " . $e->getMessage());
}

// Test search with a simple query
$query = "test";
$searchTerm = "%$query%";

try {
    $stmt = $db->prepare("SELECT id, title, author FROM books WHERE title LIKE ? OR author LIKE ? LIMIT 3");
    $stmt->execute([$searchTerm, $searchTerm]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Search test successful. Found " . count($results) . " results.<br>";
    foreach ($results as $result) {
        echo "- " . htmlspecialchars($result['title']) . " by " . htmlspecialchars($result['author']) . "<br>";
    }
} catch (Exception $e) {
    echo "Search error: " . $e->getMessage() . "<br>";
}
?>