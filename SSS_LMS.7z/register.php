<?php
require_once 'includes/config.php';


if (isLoggedIn()) {
    $userRole = getUserRole();
    redirect(getDashboardByRole($userRole));
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone = trim($_POST['phone'] ?? '');
    $age = isset($_POST['age']) && !empty($_POST['age']) ? (int)$_POST['age'] : null;
    $sex = isset($_POST['sex']) ? trim($_POST['sex']) : '';
    $school_id = trim($_POST['school_id'] ?? '');
    
    // Validate input
    if (empty($username)) $errors[] = 'Username is required';
    if (empty($email)) $errors[] = 'Email is required';
    if (empty($password)) $errors[] = 'Password is required';
    if (empty($first_name)) $errors[] = 'First name is required';
    if (empty($last_name)) $errors[] = 'Last name is required';
    if ($password !== $confirm_password) $errors[] = 'Passwords do not match';
    
    if (strlen($username) > 50) $errors[] = 'Username too long';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters';
    if ($age !== null && ($age < 0 || $age > 150)) $errors[] = 'Please enter a valid age';
    
    // Determine role based on school ID
    $role_id = ROLE_REGULAR; // Default role
    
    if (!empty($school_id)) {
        try {
            $stmt = $db->prepare("SELECT * FROM school_ids WHERE school_id = ? AND status = 'active' AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)");
            $stmt->execute([strtoupper($school_id)]);
            $valid_id = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($valid_id) {
                if ($valid_id['role_type'] === 'student') {
                    $role_id = ROLE_STUDENT;
                } elseif ($valid_id['role_type'] === 'teacher') {
                    $role_id = ROLE_TEACHER;
                }
            } else {
                $errors[] = 'Invalid or expired school ID. Please check your ID or contact administrator.';
            }
        } catch (PDOException $e) {
            $errors[] = 'Error validating school ID: ' . $e->getMessage();
        }
    }
    
    if (empty($errors)) {
        try {
            $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = 'Username or email already exists';
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $db->prepare("INSERT INTO users (username, email, password, first_name, last_name, phone, age, sex, role_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$username, $email, $hashedPassword, $first_name, $last_name, $phone, $age, $sex, $role_id]);
                
                $user_id = $db->lastInsertId();
                
                // Update school ID as used if applicable
                if (!empty($school_id) && isset($valid_id)) {
                    $updateStmt = $db->prepare("UPDATE school_ids SET status = 'used', used_by = ?, used_at = CURRENT_TIMESTAMP WHERE id = ?");
                    $updateStmt->execute([$user_id, $valid_id['id']]);
                }
                
                $role_name = '';
                switch ($role_id) {
                    case ROLE_STUDENT: $role_name = 'Student'; break;
                    case ROLE_TEACHER: $role_name = 'Teacher'; break;
                    default: $role_name = 'Regular User';
                }
                
                $success = "Registration successful as {$role_name}! You can now <a href='/login.php' class='auth-link'>login</a>.";
            }
        } catch (PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Sabian</title>
    <link rel="stylesheet" href="assets/css/base/reset.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/base/variables.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/alerts.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/badges.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/cards.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/header.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/forms.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/modals.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/search.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/tables.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/components/buttons.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/layouts/container.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/pages/id.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/utilities/animations.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/utilities/responsive.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/utilities/dark-mode.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/utilities/typography.css" type="text/css" media="all" />
<link rel="stylesheet" href="assets/css/utilities/utilities.css" type="text/css" media="all" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="assets/js/index.js" charset="utf-8" defer></script>
<script src="assets/js/modal.js" charset="utf-8" defer></script>
<script src="assets/js/form.js" charset="utf-8" defer></script>
    <style type="text/css" media="all">
      .text-success,
      .strength-strong{
        padding: 10px;
        color: var(--success);
        background: rgba(255,255,255,0.15);
        border-radius: 10px;
        font-weight: bold;
      }
      
      
      .strength-medium {
        padding: 10px;
        color: var(--warning);
        background: rgba(255,255,255,0.15);
        border-radius: 10px;
        font-weight: bold;
      }
      
      .text-error,
      .strength-weak {
        padding: 10px;
        color: var(--error);
        background: rgba(255,255,255,0.15);
        border-radius: 10px;
        font-weight: bold;
      }
      [data-theme="dark"] .strength-strong,
      .strength-weak,
      strength-medium,
      .text-error,
      text-success{
    background: rgba(0,0,0,0.15);
}
    </style>
</head>
<body>
  <div class="auth-page">
    
  
    <div class="auth-container">
        <div class="auth-card">
              <button class="theme-toggle theme-register" id="mobileThemeToggle" style="background: var(--dark-1);">
            <i class="fas fa-moon"></i>
            <span class="theme-text">Dark Mode</span>
        </button>
            <div class="auth-header">
                <div class="auth-brand">
                    <i class="fas fa-book-open brand-icon"></i>
                    <span class="brand-text">Sabian</span>
                </div>
                <h1 class="auth-title">Create Account</h1>
                <p class="auth-subtitle">Join our community</p>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php foreach ($errors as $error): ?>
                        <div><?php echo htmlspecialchars($error); ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success; ?>
                </div>
                <div class="text-center mt-3">
                    <a href="login.php" class="btn btn-primary btn-block">Proceed to Login</a>
                </div>
            <?php else: ?>

            <form method="POST" action="" class="auth-form" id="registerForm">
                <h4 class="form-section-title">Personal Information</h4>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name" class="form-label">First Name</label>
                        <div class="input-with-icon">
                            <i class="fas fa-user input-icon"></i>
                            <input type="text" 
                                   class="input" 
                                   id="first_name" 
                                   name="first_name" 
                                   required 
                                   placeholder="Enter your first name"
                                   value="<?php echo isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name" class="form-label">Last Name</label>
                        <div class="input-with-icon">
                            <i class="fas fa-user input-icon"></i>
                            <input type="text" 
                                   class="input" 
                                   id="last_name" 
                                   name="last_name" 
                                   required 
                                   placeholder="Enter your last name"
                                   value="<?php echo isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : ''; ?>">
                        </div>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="age" class="form-label">Age</label>
                        <div class="input-with-icon">
                            <i class="fas fa-birthday-cake input-icon"></i>
                            <input type="number" 
                                   class="input" 
                                   id="age" 
                                   name="age" 
                                   min="0" 
                                   max="150" 
                                   placeholder="Your age"
                                   value="<?php echo isset($_POST['age']) ? htmlspecialchars($_POST['age']) : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="sex" class="form-label">Gender</label>
                        <div class="input-with-icon">
                            <i class="fas fa-venus-mars input-icon"></i>
                            <select class="input" id="sex" name="sex">
                                <option value="">Select Gender</option>
                                <option value="male" <?php echo (isset($_POST['sex']) && $_POST['sex'] === 'male') ? 'selected' : ''; ?>>Male</option>
                                <option value="female" <?php echo (isset($_POST['sex']) && $_POST['sex'] === 'female') ? 'selected' : ''; ?>>Female</option>
                                <option value="other" <?php echo (isset($_POST['sex']) && $_POST['sex'] === 'other') ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                    </div>
                </div>

                <h4 class="form-section-title">Account Details</h4>
                
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <div class="input-with-icon">
                        <i class="fas fa-user-circle input-icon"></i>
                        <input type="text" 
                               class="input" 
                               id="username" 
                               name="username" 
                               required 
                               placeholder="Choose a username"
                               value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                    </div>

                </div>
                
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <div class="input-with-icon">
                        <i class="fas fa-envelope input-icon"></i>
                        <input type="email" 
                               class="input" 
                               id="email" 
                               name="email" 
                               required 
                               placeholder="your.email@example.com"
                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="phone" class="form-label">Phone Number</label>
                    <div class="input-with-icon">
                        <i class="fas fa-phone input-icon"></i>
                        <input type="tel" 
                               class="input" 
                               id="phone" 
                               name="phone" 
                               placeholder="+1234567890"
                               value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                    </div>
                </div>

                <h4 class="form-section-title">School Information (Optional)</h4>
                
                <div class="form-group">
                    <label for="school_id" class="form-label">School ID</label>
                    <div class="input-with-icon">
                        <i class="fas fa-id-card input-icon"></i>
                        <input type="text" 
                               class="input" 
                               id="school_id" 
                               name="school_id" 
                               placeholder="STU123456 or TCH123456"
                               value="<?php echo isset($_POST['school_id']) ? htmlspecialchars($_POST['school_id']) : ''; ?>">
                    </div>

                    <div id="role-preview" class="role-preview"></div>
                </div>

                <h4 class="form-section-title">Security</h4>
                
                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" 
                               class="input" 
                               id="password" 
                               name="password" 
                               required 
                               placeholder="Create a password">
                        <button type="button" class="input-action" id="togglePassword">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="password-strength" id="passwordStrength"></div>

                </div>
                
                <div class="form-group">
                    <label for="confirm_password" class="form-label">Confirm Password</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" 
                               class="input" 
                               id="confirm_password" 
                               name="confirm_password" 
                               required 
                               placeholder="Confirm your password">
                    </div>
                    <div class="form-hint" id="passwordMatch"></div>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                <input type="checkbox" id="terms" name="terms" required>
                        <span>I agree to the <a href="#" class="auth-link" onclick="openTermsModal()">Terms and Conditions</a></span>
                        
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block btn-md">
                    <i class="fas fa-user-plus"></i>
                    Create Account
                </button>
                <br /><br />
                <button type="reset" class="btb btn-outline btn-sm">
                  Reset
                </button>
            </form>

            <div class="auth-footer">
                <p class="auth-link-text">Already have an account? <a href="login.php" class="auth-link">Login here</a></p>
                

            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Terms Modal -->
    <div class="modal-overlay" id="termsModal">
        <div class="modal">
            <div class="modal-header">
                <h3>Terms and Conditions</h3>
                <button class="modal-close" onclick="closeTermsModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <p>By creating an account, you agree to:</p>
                <ul>
                    <li>Maintain the confidentiality of your account credentials</li>
                    <li>Use the platform for educational purposes only</li>
                    <li>Respect other users and maintain a professional environment</li>
                    <li>Follow all institutional policies and guidelines</li>
                </ul>
                <p>Student and Teacher accounts require valid school identification.</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" onclick="closeTermsModal()">I Understand</button>
            </div>
        </div>
    </div>



  </div>
</body>
</html>