<?php
define('BASE_DIR', __DIR__);
define('DB_DIR', BASE_DIR);  // Changed from BASE_DIR . '/includes'
define('DB_FILE', DB_DIR . '/database.db');

try {
    // Create directory if it doesn't exist
    if (!is_dir(DB_DIR)) {
        if (!mkdir(DB_DIR, 0755, true)) {
            throw new Exception("Could not create directory: " . DB_DIR);
        }
        echo "Created directory: " . DB_DIR . "<br>";
    }

    // Check if directory is writable
    if (!is_writable(DB_DIR)) {
        throw new Exception("Directory is not writable: " . DB_DIR);
    }

    // Remove existing database file if it exists
    if (file_exists(DB_FILE)) {
        if (!unlink(DB_FILE)) {
            throw new Exception("Could not delete existing database file");
        }
        echo "Removed existing database file: " . DB_FILE . "<br>";
    } else {
        echo "No existing database file found at: " . DB_FILE . "<br>";
    }

    // Create database connection
    $db = new PDO('sqlite:' . DB_FILE);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Disable foreign keys temporarily
    $db->exec("PRAGMA foreign_keys = OFF");
    
    echo "Database connection established<br>";

    // Step 1: Create user_roles table first
    echo "Creating user_roles table...<br>";
    $db->exec("CREATE TABLE user_roles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_name TEXT UNIQUE NOT NULL,
        description TEXT,
        permissions TEXT,
        access_level INTEGER DEFAULT 50,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    echo "✓ user_roles table created successfully<br>";

    // Step 2: Create users table
    echo "Creating users table...<br>";
    $db->exec("CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        school_id TEXT UNIQUE,
        phone TEXT,
        age INTEGER,
        sex TEXT CHECK(sex IN ('male', 'female', 'other')),
        profile_pic TEXT,
        bio TEXT,
        location TEXT,
        website TEXT,
        role_id INTEGER DEFAULT 5,
        id_verified BOOLEAN DEFAULT 0,
        membership_status TEXT CHECK(membership_status IN ('active', 'inactive', 'suspended', 'graduated')) DEFAULT 'active',
        membership_expiry DATETIME,
        last_active DATETIME,
        last_login DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (role_id) REFERENCES user_roles(id)
    )");
    echo "✓ users table created successfully<br>";

    // Step 3: Create school_ids table
    echo "Creating school_ids table...<br>";
    $db->exec("CREATE TABLE school_ids (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        school_id TEXT UNIQUE NOT NULL,
        role_type TEXT CHECK(role_type IN ('student', 'teacher')) NOT NULL,
        status TEXT CHECK(status IN ('active', 'used', 'revoked', 'expired')) DEFAULT 'active',
        generated_by INTEGER,
        used_by INTEGER NULL,
        generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        used_at DATETIME NULL,
        expires_at DATETIME NULL,
        notes TEXT,
        FOREIGN KEY (generated_by) REFERENCES users(id),
        FOREIGN KEY (used_by) REFERENCES users(id)
    )");
    echo "✓ school_ids table created successfully<br>";

    // Step 4: Create categories table
    echo "Creating categories table...<br>";
    $db->exec("CREATE TABLE categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT,
        parent_id INTEGER,
        depth_level INTEGER DEFAULT 0,
        icon TEXT,
        color TEXT,
        sort_order INTEGER DEFAULT 0,
        book_count INTEGER DEFAULT 0,
        is_active BOOLEAN DEFAULT 1,
        is_featured BOOLEAN DEFAULT 0,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (parent_id) REFERENCES categories(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    echo "✓ categories table created successfully<br>";

    // Step 5: Create suppliers table
    echo "Creating suppliers table...<br>";
    $db->exec("CREATE TABLE suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        contact_person TEXT,
        email TEXT,
        phone TEXT,
        address TEXT,
        city TEXT,
        country TEXT,
        tax_id TEXT,
        payment_terms TEXT,
        rating INTEGER DEFAULT 5,
        status TEXT CHECK(status IN ('active', 'inactive', 'blacklisted')) DEFAULT 'active',
        notes TEXT,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    echo "✓ suppliers table created successfully<br>";

    // Step 6: Create books table
    echo "Creating books table...<br>";
    $db->exec("CREATE TABLE books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        isbn TEXT UNIQUE,
        title TEXT NOT NULL,
        author TEXT NOT NULL,
        description TEXT,
        publisher TEXT,
        publication_year INTEGER,
        edition TEXT,
        language TEXT DEFAULT 'English',
        page_count INTEGER,
        cover_image TEXT,
        access_type TEXT CHECK(access_type IN ('public', 'registered', 'educational')) DEFAULT 'registered',
        status TEXT CHECK(status IN ('active', 'inactive', 'archived', 'lost')) DEFAULT 'active',
        total_copies INTEGER DEFAULT 1,
        available_copies INTEGER DEFAULT 1,
        is_digital BOOLEAN DEFAULT 0,
        file_path TEXT,
        file_format TEXT,
        file_size INTEGER,
        preview_pages INTEGER DEFAULT 10,
        supplier_id INTEGER,
        purchase_price DECIMAL(10,2),
        purchase_date DATE,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    echo "✓ books table created successfully<br>";

    // Step 7: Create book_categories table
    echo "Creating book_categories table...<br>";
    $db->exec("CREATE TABLE book_categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        book_id INTEGER NOT NULL,
        category_id INTEGER NOT NULL,
        is_primary BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
        UNIQUE(book_id, category_id)
    )");
    echo "✓ book_categories table created successfully<br>";

    // Step 8: Create book_access_rules table
    echo "Creating book_access_rules table...<br>";
    $db->exec("CREATE TABLE book_access_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        book_id INTEGER NOT NULL,
        allowed_roles TEXT NOT NULL,
        requires_payment BOOLEAN DEFAULT 0,
        payment_amount DECIMAL(10,2) DEFAULT 0.00,
        borrow_limit_days INTEGER DEFAULT 14,
        max_renewals INTEGER DEFAULT 1,
        max_copies_per_user INTEGER DEFAULT 1,
        reservation_allowed BOOLEAN DEFAULT 1,
        reservation_duration_days INTEGER DEFAULT 7,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
    )");
    echo "✓ book_access_rules table created successfully<br>";

    // Step 9: Create user_borrow_limits table
    echo "Creating user_borrow_limits table...<br>";
    $db->exec("CREATE TABLE user_borrow_limits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_id INTEGER NOT NULL,
        max_borrowed_books INTEGER NOT NULL,
        max_reservations INTEGER NOT NULL,
        payment_exempt BOOLEAN DEFAULT 0,
        discount_percentage INTEGER DEFAULT 0,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (role_id) REFERENCES user_roles(id)
    )");
    echo "✓ user_borrow_limits table created successfully<br>";

    // Step 10: Create borrow_transactions table
    echo "Creating borrow_transactions table...<br>";
    $db->exec("CREATE TABLE borrow_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        book_id INTEGER NOT NULL,
        transaction_type TEXT CHECK(transaction_type IN ('borrow', 'reserve', 'renew')) NOT NULL,
        previous_transaction_id INTEGER,
        request_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        approved_date DATETIME,
        borrow_date DATETIME,
        due_date DATETIME,
        return_date DATETIME,
        status TEXT CHECK(status IN ('pending', 'approved', 'active', 'returned', 'overdue', 'cancelled')) DEFAULT 'pending',
        requires_payment BOOLEAN DEFAULT 0,
        payment_amount DECIMAL(10,2) DEFAULT 0.00,
        payment_status TEXT CHECK(payment_status IN ('pending', 'paid', 'waived', 'refunded')) DEFAULT 'pending',
        approved_by INTEGER,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (book_id) REFERENCES books(id),
        FOREIGN KEY (previous_transaction_id) REFERENCES borrow_transactions(id),
        FOREIGN KEY (approved_by) REFERENCES users(id)
    )");
    echo "✓ borrow_transactions table created successfully<br>";

    // Step 11: Create payments table
    echo "Creating payments table...<br>";
    $db->exec("CREATE TABLE payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        transaction_id INTEGER,
        amount DECIMAL(10,2) NOT NULL,
        payment_method TEXT CHECK(payment_method IN ('cash', 'online', 'card', 'voucher', 'waived')) NOT NULL,
        payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        transaction_reference TEXT,
        status TEXT CHECK(status IN ('pending', 'completed', 'failed', 'refunded')) DEFAULT 'pending',
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (transaction_id) REFERENCES borrow_transactions(id)
    )");
    echo "✓ payments table created successfully<br>";

    // Step 12: Create fines table
    echo "Creating fines table...<br>";
    $db->exec("CREATE TABLE fines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        transaction_id INTEGER NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        reason TEXT CHECK(reason IN ('overdue', 'damage', 'lost', 'other')) NOT NULL,
        description TEXT,
        status TEXT CHECK(status IN ('unpaid', 'paid', 'waived')) DEFAULT 'unpaid',
        due_date DATE NOT NULL,
        paid_date DATE,
        waived_by INTEGER,
        waived_reason TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (transaction_id) REFERENCES borrow_transactions(id),
        FOREIGN KEY (waived_by) REFERENCES users(id)
    )");
    echo "✓ fines table created successfully<br>";

    // Step 13: Create purchase_orders table
    echo "Creating purchase_orders table...<br>";
    $db->exec("CREATE TABLE purchase_orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_number TEXT UNIQUE NOT NULL,
        supplier_id INTEGER NOT NULL,
        total_amount DECIMAL(10,2) DEFAULT 0.00,
        status TEXT CHECK(status IN ('draft', 'ordered', 'received', 'cancelled')) DEFAULT 'draft',
        order_date DATE DEFAULT CURRENT_DATE,
        expected_date DATE,
        received_date DATE,
        shipping_cost DECIMAL(10,2) DEFAULT 0.00,
        tracking_number TEXT,
        created_by INTEGER,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    echo "✓ purchase_orders table created successfully<br>";

    // Step 14: Create purchase_order_items table
    echo "Creating purchase_order_items table...<br>";
    $db->exec("CREATE TABLE purchase_order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        book_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        unit_price DECIMAL(10,2) NOT NULL,
        total_price DECIMAL(10,2) NOT NULL,
        received_quantity INTEGER DEFAULT 0,
        notes TEXT,
        FOREIGN KEY (order_id) REFERENCES purchase_orders(id) ON DELETE CASCADE,
        FOREIGN KEY (book_id) REFERENCES books(id)
    )");
    echo "✓ purchase_order_items table created successfully<br>";

    // Step 15: Create contacts table
    echo "Creating contacts table...<br>";
    $db->exec("CREATE TABLE contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT CHECK(type IN ('customer', 'supplier', 'partner', 'other')) NOT NULL,
        company_name TEXT,
        contact_person TEXT,
        email TEXT,
        phone TEXT,
        address TEXT,
        city TEXT,
        country TEXT,
        tax_id TEXT,
        payment_terms TEXT,
        status TEXT CHECK(status IN ('active', 'inactive')) DEFAULT 'active',
        notes TEXT,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    echo "✓ contacts table created successfully<br>";

    // Step 16: Create sales table
    echo "Creating sales table...<br>";
    $db->exec("CREATE TABLE sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        contact_id INTEGER,
        sale_type TEXT CHECK(sale_type IN ('book_sale', 'membership', 'service', 'other')) NOT NULL,
        total_amount DECIMAL(10,2) DEFAULT 0.00,
        discount_amount DECIMAL(10,2) DEFAULT 0.00,
        tax_amount DECIMAL(10,2) DEFAULT 0.00,
        final_amount DECIMAL(10,2) DEFAULT 0.00,
        payment_status TEXT CHECK(payment_status IN ('pending', 'paid', 'partial', 'cancelled')) DEFAULT 'pending',
        payment_method TEXT,
        sale_date DATE DEFAULT CURRENT_DATE,
        notes TEXT,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (contact_id) REFERENCES contacts(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    echo "✓ sales table created successfully<br>";

    // Step 17: Create sale_items table
    echo "Creating sale_items table...<br>";
    $db->exec("CREATE TABLE sale_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_id INTEGER NOT NULL,
        book_id INTEGER,
        item_type TEXT CHECK(item_type IN ('book', 'membership', 'service', 'other')) NOT NULL,
        description TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        unit_price DECIMAL(10,2) NOT NULL,
        total_price DECIMAL(10,2) NOT NULL,
        notes TEXT,
        FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
        FOREIGN KEY (book_id) REFERENCES books(id)
    )");
    echo "✓ sale_items table created successfully<br>";

    // Step 18: Create financial_transactions table
    echo "Creating financial_transactions table...<br>";
    $db->exec("CREATE TABLE financial_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT CHECK(type IN ('income', 'expense', 'refund')) NOT NULL,
        category TEXT NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        description TEXT,
        reference_id INTEGER,
        reference_table TEXT,
        created_by INTEGER,
        transaction_date DATE DEFAULT CURRENT_DATE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    echo "✓ financial_transactions table created successfully<br>";

    // Step 19: Create system_reports table
    echo "Creating system_reports table...<br>";
    $db->exec("CREATE TABLE system_reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        report_name TEXT NOT NULL,
        report_type TEXT CHECK(report_type IN ('borrowing', 'financial', 'inventory', 'user', 'custom')) NOT NULL,
        description TEXT,
        is_scheduled BOOLEAN DEFAULT 0,
        schedule_frequency TEXT CHECK(schedule_frequency IN ('daily', 'weekly', 'monthly', 'quarterly')),
        last_generated DATETIME,
        parameters TEXT,
        output_format TEXT CHECK(output_format IN ('pdf', 'excel', 'html')) DEFAULT 'pdf',
        created_by INTEGER,
        is_public BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    echo "✓ system_reports table created successfully<br>";

    // Step 20: Create report_schedules table
    echo "Creating report_schedules table...<br>";
    $db->exec("CREATE TABLE report_schedules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        report_id INTEGER NOT NULL,
        frequency TEXT CHECK(frequency IN ('daily', 'weekly', 'monthly')) NOT NULL,
        day_of_week INTEGER,
        day_of_month INTEGER,
        time_of_day TIME,
        recipient_emails TEXT,
        is_active BOOLEAN DEFAULT 1,
        last_run DATETIME,
        next_run DATETIME,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (report_id) REFERENCES system_reports(id) ON DELETE CASCADE
    )");
    echo "✓ report_schedules table created successfully<br>";

    // Step 21: Create system_settings table
    echo "Creating system_settings table...<br>";
    $db->exec("CREATE TABLE system_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        setting_key TEXT UNIQUE NOT NULL,
        setting_value TEXT NOT NULL,
        setting_type TEXT CHECK(setting_type IN ('string', 'integer', 'boolean', 'json', 'array')) DEFAULT 'string',
        category TEXT DEFAULT 'general',
        description TEXT,
        is_public BOOLEAN DEFAULT 0,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    echo "✓ system_settings table created successfully<br>";

    // Step 22: Create audit_log table
    // ... existing code ...

// Step 22: Create audit_log table
echo "Creating audit_log table...<br>";
$db->exec("CREATE TABLE audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action TEXT NOT NULL,
    table_name TEXT NOT NULL,
    record_id INTEGER,
    old_values TEXT,
    new_values TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");
echo "✓ audit_log table created successfully<br>";

// Now enable foreign keys
$db->exec("PRAGMA foreign_keys = ON");
echo "Foreign keys enabled<br>";

// Insert user roles
echo "Inserting user roles...<br>";
$roles = [
    [1, 'admin', 'System Administrator', 'all', 100],
    [2, 'librarian', 'Library Manager', 'manage_books,manage_users,view_reports', 90],
    [3, 'teacher', 'Teacher/Instructor', 'manage_courses,view_students,upload_content', 80],
    [4, 'student', 'Student', 'borrow_books,view_courses,submit_assignments', 70],
    [5, 'regular', 'Regular User', 'basic_access,view_public_content', 50]
];

foreach ($roles as $role) {
    $stmt = $db->prepare("INSERT INTO user_roles (id, role_name, description, permissions, access_level) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute($role);
    echo "✓ Inserted role: " . $role[1] . "<br>";
}

// INSERT USERS FIRST (MOVED UP)
echo "Inserting users...<br>";

// Admin user
$hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO users (id, username, email, password, first_name, last_name, school_id, phone, age, sex, role_id, id_verified, last_active, last_login) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->execute([1, 'admin', 'admin@example.com', $hashedPassword, 'John', 'Doe', 'ADM-2024-001', '+1234567890', 35, 'male', 1, 1, date('Y-m-d H:i:s'), date('Y-m-d H:i:s')]);
echo "✓ Created admin user<br>";

// Librarian user
$hashedPassword = password_hash('lib123', PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO users (id, username, email, password, first_name, last_name, school_id, phone, age, sex, role_id, id_verified, last_active, last_login) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->execute([2, 'librarian', 'librarian@example.com', $hashedPassword, 'Sarah', 'Wilson', 'LIB-2024-001', '+1234567891', 42, 'female', 2, 1, date('Y-m-d H:i:s'), date('Y-m-d H:i:s')]);
echo "✓ Created librarian user<br>";

// Teacher user
$hashedPassword = password_hash('teacher123', PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO users (id, username, email, password, first_name, last_name, school_id, phone, age, sex, role_id, id_verified, last_active, last_login) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->execute([3, 'teacher', 'teacher@example.com', $hashedPassword, 'Michael', 'Brown', 'TCH-2024-001', '+1234567892', 38, 'male', 3, 1, date('Y-m-d H:i:s'), date('Y-m-d H:i:s')]);
echo "✓ Created teacher user<br>";

// Student user
$hashedPassword = password_hash('student123', PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO users (id, username, email, password, first_name, last_name, school_id, phone, age, sex, role_id, id_verified, last_active, last_login) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->execute([4, 'student', 'student@example.com', $hashedPassword, 'Emily', 'Johnson', 'STU-2024-001', '+1234567893', 20, 'female', 4, 1, date('Y-m-d H:i:s'), date('Y-m-d H:i:s')]);
echo "✓ Created student user<br>";

// Regular user
$hashedPassword = password_hash('user123', PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO users (id, username, email, password, first_name, last_name, phone, age, sex, role_id, id_verified, last_active, last_login) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->execute([5, 'user1', 'user1@example.com', $hashedPassword, 'Jane', 'Smith', '+0987654321', 28, 'female', 5, 1, date('Y-m-d H:i:s'), date('Y-m-d H:i:s')]);
echo "✓ Created regular user<br>";

// NOW INSERT CATEGORIES (MOVED DOWN)
echo "Inserting sample categories...<br>";
$categories = [
    [1, 'Fiction', 'fiction', 'Novels, short stories, and literary works', NULL, 0, 'fa-book-open', '#4CAF50', 1, 0, 1, 0, 1],
    [2, 'Academic', 'academic', 'Textbooks and educational materials', NULL, 0, 'fa-graduation-cap', '#2196F3', 2, 0, 1, 0, 1],
    [3, 'Science & Technology', 'science-technology', 'Scientific and technical publications', NULL, 0, 'fa-flask', '#9C27B0', 3, 0, 1, 0, 1],
    [4, 'Arts & Humanities', 'arts-humanities', 'Creative arts, philosophy, and social sciences', NULL, 0, 'fa-palette', '#FF9800', 4, 0, 1, 0, 1],
    [5, 'Reference', 'reference', 'Dictionaries, encyclopedias, and guides', NULL, 0, 'fa-search', '#795548', 5, 0, 1, 0, 1],
    [6, 'Children & Young Adult', 'children-ya', 'Books for young readers', NULL, 0, 'fa-child', '#E91E63', 6, 0, 1, 0, 1],
    [7, 'Science Fiction', 'science-fiction', 'Futuristic and speculative fiction', 1, 1, 'fa-robot', '#4CAF50', 1, 0, 1, 0, 1],
    [8, 'Mathematics', 'mathematics', 'Math textbooks and references', 2, 1, 'fa-square-root-alt', '#2196F3', 1, 0, 1, 0, 1],
    [9, 'Computer Science', 'computer-science', 'Programming and technology', 2, 1, 'fa-laptop-code', '#2196F3', 2, 0, 1, 0, 1]
];

foreach ($categories as $category) {
    $stmt = $db->prepare("INSERT INTO categories (id, name, slug, description, parent_id, depth_level, icon, color, sort_order, book_count, is_active, is_featured, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute($category);
    echo "✓ Inserted category: " . $category[1] . "<br>";
}

// ... continue with the rest of the script (user_borrow_limits, system_settings, suppliers, books, etc.) ...

    // Insert system settings
    echo "Inserting system settings...<br>";
    $settings = [
        ['library_name', 'Sabian Library', 'string', 'general', 'Name of the library'],
        ['max_borrow_days', '14', 'integer', 'borrowing', 'Default borrow period'],
        ['overdue_fine_per_day', '0.50', 'string', 'financial', 'Daily overdue fine'],
        ['currency', 'USD', 'string', 'financial', 'Default currency'],
        ['reservation_duration', '7', 'integer', 'borrowing', 'Days to hold reserved books'],
        ['max_renewals', '1', 'integer', 'borrowing', 'Maximum renewal times'],
        ['student_borrow_limit', '5', 'integer', 'borrowing', 'Max books for students'],
        ['teacher_borrow_limit', '10', 'integer', 'borrowing', 'Max books for teachers'],
        ['library_email', 'library@sabian.edu', 'string', 'general', 'Library contact email'],
        ['library_phone', '+1-555-0123', 'string', 'general', 'Library phone number'],
        ['library_address', '123 Education Street, City, Country', 'string', 'general', 'Library physical address']
    ];

    foreach ($settings as $setting) {
        $stmt = $db->prepare("INSERT INTO system_settings (setting_key, setting_value, setting_type, category, description) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute($setting);
        echo "✓ Inserted setting: " . $setting[0] . "<br>";
    }

    // Insert sample suppliers
    echo "Inserting sample suppliers...<br>";
    $suppliers = [
        [1, 'Book Distributors Inc', 'John Smith', 'john@bookdistributors.com', '+1-555-0101', '123 Book Street, New York, NY', 'New York', 'USA', 'TAX-12345', 'Net 30', 5, 'active', 'Primary book supplier', 1],
        [2, 'Educational Resources Ltd', 'Sarah Johnson', 'sarah@eduresources.com', '+1-555-0102', '456 Education Ave, Boston, MA', 'Boston', 'USA', 'TAX-67890', 'Net 45', 4, 'active', 'Specialized in academic books', 1]
    ];

    foreach ($suppliers as $supplier) {
        $stmt = $db->prepare("INSERT INTO suppliers (id, name, contact_person, email, phone, address, city, country, tax_id, payment_terms, rating, status, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute($supplier);
        echo "✓ Inserted supplier: " . $supplier[1] . "<br>";
    }

    // Insert sample books
    // Insert sample books
echo "Inserting sample books...<br>";
$books = [
    [1, '978-0141439518', 'Pride and Prejudice', 'Jane Austen', 'A romantic novel of manners', 'Penguin Classics', 1813, 'First', 'English', 432, '/covers/pride_prejudice.jpg', 'public', 'active', 3, 3, 1, '/books/pride_prejudice.pdf', 'pdf', 2500000, 20, 1, 15.99, '2024-01-15', 1],
    [2, '978-0451524935', '1984', 'George Orwell', 'Dystopian social science fiction novel', 'Signet Classic', 1949, 'First', 'English', 328, '/covers/1984.jpg', 'registered', 'active', 5, 5, 1, '/books/1984.pdf', 'pdf', 1800000, 15, 1, 12.50, '2024-01-20', 1],
    [3, '978-0061120084', 'To Kill a Mockingbird', 'Harper Lee', 'Story of racial inequality and moral growth', 'J.B. Lippincott & Co.', 1960, 'First', 'English', 281, '/covers/mockingbird.jpg', 'educational', 'active', 2, 2, 0, NULL, NULL, NULL, 10, 2, 18.75, '2024-02-01', 1],
    [4, '978-0547928227', 'The Hobbit', 'J.R.R. Tolkien', 'Fantasy novel and children\'s book', 'George Allen & Unwin', 1937, 'First', 'English', 310, '/covers/hobbit.jpg', 'public', 'active', 4, 4, 1, '/books/hobbit.pdf', 'pdf', 2200000, 25, 1, 14.99, '2024-01-25', 1],
    [5, '978-0743273565', 'The Great Gatsby', 'F. Scott Fitzgerald', 'Classic novel about the American Dream', 'Scribner', 1925, 'First', 'English', 180, '/covers/gatsby.jpg', 'registered', 'active', 3, 3, 1, '/books/gatsby.pdf', 'pdf', 1500000, 12, 2, 16.50, '2024-02-05', 1]
];

foreach ($books as $book) {
    $stmt = $db->prepare("INSERT INTO books (id, isbn, title, author, description, publisher, publication_year, edition, language, page_count, cover_image, access_type, status, total_copies, available_copies, is_digital, file_path, file_format, file_size, preview_pages, supplier_id, purchase_price, purchase_date, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute($book);
    echo "✓ Inserted book: " . $book[2] . "<br>";
}

    // Insert book categories relationships
    echo "Creating book-category relationships...<br>";
    $bookCategories = [
        [1, 1, 1, 1], // Pride and Prejudice -> Fiction (primary)
        [2, 2, 1, 1], // 1984 -> Fiction (primary)
        [3, 3, 1, 1], // To Kill a Mockingbird -> Fiction (primary)
        [4, 4, 1, 1], // The Hobbit -> Fiction (primary)
        [5, 5, 1, 1], // The Great Gatsby -> Fiction (primary)
        [6, 2, 7, 0], // 1984 -> Science Fiction
        [7, 4, 7, 0]  // The Hobbit -> Science Fiction
    ];

    foreach ($bookCategories as $bookCat) {
        $stmt = $db->prepare("INSERT INTO book_categories (id, book_id, category_id, is_primary) VALUES (?, ?, ?, ?)");
        $stmt->execute($bookCat);
    }
    echo "✓ Created book-category relationships<br>";

    // Insert book access rules
    echo "Creating book access rules...<br>";
    $accessRules = [
        [1, 1, '["all"]', 0, 0.00, 21, 2, 1, 1, 7], // Public book - anyone
        [2, 2, '["student", "teacher", "regular", "librarian", "admin"]', 0, 0.00, 14, 1, 1, 1, 5], // Registered - free
        [3, 3, '["student", "teacher", "librarian", "admin"]', 0, 0.00, 30, 2, 2, 1, 10], // Educational - free for students/teachers
        [4, 4, '["all"]', 0, 0.00, 21, 2, 1, 1, 7], // Public book
        [5, 5, '["student", "teacher", "regular", "librarian", "admin"]', 1, 5.00, 14, 1, 1, 1, 5]  // Registered - paid
    ];

    foreach ($accessRules as $rule) {
        $stmt = $db->prepare("INSERT INTO book_access_rules (id, book_id, allowed_roles, requires_payment, payment_amount, borrow_limit_days, max_renewals, max_copies_per_user, reservation_allowed, reservation_duration_days) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute($rule);
    }
    echo "✓ Created book access rules<br>";

    // Insert users
    

    // Verify the data
    echo "<br>Verifying database setup...<br>";
    
    $tables = [
        'user_roles' => 'User Roles',
        'users' => 'Users', 
        'school_ids' => 'School IDs',
        'categories' => 'Categories',
        'suppliers' => 'Suppliers',
        'books' => 'Books',
        'book_categories' => 'Book Categories',
        'book_access_rules' => 'Book Access Rules',
        'user_borrow_limits' => 'User Borrow Limits',
        'borrow_transactions' => 'Borrow Transactions',
        'payments' => 'Payments',
        'fines' => 'Fines',
        'purchase_orders' => 'Purchase Orders',
        'purchase_order_items' => 'Purchase Order Items',
        'contacts' => 'Contacts',
        'sales' => 'Sales',
        'sale_items' => 'Sale Items',
        'financial_transactions' => 'Financial Transactions',
        'system_reports' => 'System Reports',
        'report_schedules' => 'Report Schedules',
        'system_settings' => 'System Settings',
        'audit_log' => 'Audit Log'
    ];

    foreach ($tables as $table => $name) {
        $stmt = $db->query("SELECT COUNT(*) as count FROM $table");
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "✓ $name: $count records<br>";
    }

    echo "<br><strong>🎉 Database initialized successfully!</strong><br>";
    echo "Database file: " . DB_FILE . "<br>";
    echo "Total tables created: " . count($tables) . "<br>";
    echo "You can now <a href='login.php'>login to the system</a>";

} catch (Exception $e) {
    echo "<strong>Error:</strong> " . $e->getMessage() . "<br>";
    echo "File: " . $e->getFile() . " Line: " . $e->getLine() . "<br>";
    
    // Debug information
    echo "<br><strong>Debug Information:</strong><br>";
    echo "DB File Path: " . DB_FILE . "<br>";
    echo "Directory exists: " . (is_dir(DB_DIR) ? 'Yes' : 'No') . "<br>";
    echo "Directory writable: " . (is_writable(DB_DIR) ? 'Yes' : 'No') . "<br>";
    echo "DB File exists: " . (file_exists(DB_FILE) ? 'Yes' : 'No') . "<br>";
    
    if (file_exists(DB_FILE)) {
        echo "DB File size: " . filesize(DB_FILE) . " bytes<br>";
        echo "DB File readable: " . (is_readable(DB_FILE) ? 'Yes' : 'No') . "<br>";
        echo "DB File writable: " . (is_writable(DB_FILE) ? 'Yes' : 'No') . "<br>";
    }
}
?>