<?php
// header.php - Add this at the top

require_once 'config.php';

// Only redirect if not already on an admin/librarian page
if (isLoggedIn()) {
    $userRole = getUserRole();
    redirect(getDashboardByRole($userRole));
}

// ... rest of your existing header.php code ...

// Get current user data from database
$current_user = null;
$is_guest = false;

if (isLoggedIn()) {
  try {
    $stmt = $db->prepare("SELECT u.*, ur.role_name, ur.description as role_description 
                         FROM users u 
                         JOIN user_roles ur ON u.role_id = ur.id 
                         WHERE u.id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $current_user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Generate avatar URL based on name
    if ($current_user) {
      $avatar_name = urlencode($current_user['first_name'] . '+' . $current_user['last_name']);
      $current_user['avatar_url'] = "https://ui-avatars.com/api/?name={$avatar_name}&background=0f2a1d&color=fff&size=120";

      // Generate initials for fallback
      $current_user['initials'] = strtoupper(
        substr($current_user['first_name'], 0, 1) .
        substr($current_user['last_name'], 0, 1)
      );
    }
  } catch (Exception $e) {
    error_log("Error fetching user data: " . $e->getMessage());
    $is_guest = true;
  }
} else {
  $is_guest = true;
}

// Guest user data
if ($is_guest) {
  $current_user = [
    'first_name' => 'Guest',
    'last_name' => 'Account',
    'role_name' => 'guest',
    'role_description' => 'Guest User',
    'profile_pic' => null,
    'avatar_url' => '',
    'initials' => 'GA'
  ];
}

// Function to get role display name
function getRoleDisplayName($role_name) {
    $role_names = [
        'admin' => 'Administrator',
        'librarian' => 'Librarian',
        'teacher' => 'Teacher',
        'student' => 'Student',
        'regular' => 'Regular User',
        'guest' => 'Guest'
    ];
    return $role_names[$role_name] ?? 'User';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Preload critical resources -->
  <link rel="preload" href="css/styles.css" as="style">
  <meta http-equiv="Cache-Control" content="max-age=31536000">

  <!-- Compress your files with Gzip/Brotli -->
  <title>Library - Responsive Header</title>
<!-- Base Styles -->
<link rel="stylesheet" href="../assets/css/base/reset.css">
<link rel="stylesheet" href="../assets/css/base/variables.css">

<!-- Layouts -->
<link rel="stylesheet" href="../assets/css/layouts/container.css">

<!-- Components -->
<link rel="stylesheet" href="../assets/css/components/alerts.css">
<link rel="stylesheet" href="../assets/css/components/badges.css">
<link rel="stylesheet" href="../assets/css/components/buttons.css">
<link rel="stylesheet" href="../assets/css/components/cards.css">
<link rel="stylesheet" href="../assets/css/components/forms.css">
<link rel="stylesheet" href="../assets/css/components/tables.css">
<link rel="stylesheet" href="../assets/css/components/header.css">
<link rel="stylesheet" href="../assets/css/components/modals.css">
<link rel="stylesheet" href="../assets/css/components/search.css">

<link rel="stylesheet" href="../assets/css/pages/generate.css">
<link rel="stylesheet" href="../assets/css/pages/profile.css">

<!-- Utilities -->
<link rel="stylesheet" href="../assets/css/utilities/animations.css">
<link rel="stylesheet" href="../assets/css/utilities/responsive.css">
<link rel="stylesheet" href="../assets/css/utilities/utilities.css">
<link rel="stylesheet" href="../assets/css/utilities/dark-mode.css">

<!-- External -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<header class="header" id="headerNavbar" data-reveal="top">
<div class="header-container">
<div class="header-content">
<div class="search-expanded" id="searchExpanded">
<div class="search-container">
<i class="fas fa-search search-icon"></i>
<input type="text" class="search-input" placeholder="Search books, members..." id="mobileSearchInput">
<button class="search-close" id="searchClose">
<i class="fas fa-times"></i>
</button>
</div>
</div>

<div class="brand">
<i class="fas fa-book-open brand-icon"></i>
<span class="brand-text">Sabian</span>
</div>

<nav class="nav">
<div class="search-container">
<i class="fas fa-search search-icon"></i>
<input type="text" class="search-input" placeholder="Search books, members...">
</div>

<ul class="nav-links">
<li><a href="dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>"><i class="fas fa-home"></i> <span>Dashboard</span><div class="tooltip">Dashboard</div></a></li>
<li><a href="books.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'books.php' ? 'active' : ''; ?>"><i class="fas fa-book"></i> <span>Books</span><div class="tooltip">Books</div></a></li>
<li><a href="members.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'members.php' ? 'active' : ''; ?>"><i class="fas fa-users"></i> <span>Members</span><div class="tooltip">Members</div></a></li>
<li><a href="reports.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>"><i class="fas fa-chart-bar"></i> <span>Reports</span><div class="tooltip">Reports</div></a></li>
</ul>
</nav>

<div class="header-actions">
    <button class="theme-toggle" id="themeToggle">
        <i class="fas fa-moon"></i>
        <span class="theme-text">Dark Mode</span>
    </button>

    <button class="search-toggle" id="searchToggle">
        <i class="fas fa-search"></i>
    </button>

    <!-- User Menu Container - Desktop Dropdown -->
    <div class="user-menu-container">
        <div class="user-avatar" id="userAvatar">
            <?php if (!$is_guest && !empty($current_user['profile_pic'])): ?>
                <img src="<?php echo htmlspecialchars($current_user['profile_pic']); ?>" alt="Profile" class="user-avatar-img">
            <?php elseif (!$is_guest): ?>
                <img src="<?php echo $current_user['avatar_url']; ?>" alt="Profile" class="user-avatar-img">
            <?php else : ?>
                <i class="fas fa-user-circle user-icon"></i>
            <?php endif; ?>
        </div>

        <!-- Dropdown Menu -->
        <div class="sub-menu-wrap" id="subMenu">
            <div class="sub-menu">
                <!-- User Header -->
                <div class="user-info">
                    <div class="user-avatar">
                        <?php if (!$is_guest && !empty($current_user['profile_pic'])): ?>
                            <img src="<?php echo htmlspecialchars($current_user['profile_pic']); ?>" alt="Profile" class="user-avatar-img">
                        <?php elseif (!$is_guest): ?>
                            <img src="<?php echo $current_user['avatar_url']; ?>" alt="Profile" class="user-avatar-img">
                        <?php else : ?>
                            <i class="fas fa-user-circle user-icon"></i>
                        <?php endif; ?>
                    </div>
                    <div class="user-details">
                        <h3><?php echo htmlspecialchars($current_user['first_name'] . ' ' . $current_user['last_name']); ?></h3>
                        <p class="user-role">
                            <?php echo getRoleDisplayName($current_user['role_name'] ?? 'guest'); ?>
                        </p>
                    </div>
                </div>

                <!-- Menu Items - Show different options for guest vs logged in -->
                <?php if ($is_guest): ?>
                    <a class="sub-menu-link" href="../login.php">
                        <i class="fas fa-sign-in-alt menu-icon"></i>
                        <p>Login</p>
                        <i class="fas fa-chevron-right arrow-icon"></i>
                    </a>

                    <a class="sub-menu-link" href="../register.php">
                        <i class="fas fa-user-plus menu-icon"></i>
                        <p>Register</p>
                        <i class="fas fa-chevron-right arrow-icon"></i>
                    </a>

                    <hr class="menu-divider">

                    <a class="sub-menu-link" href="help.php">
                        <i class="fas fa-question-circle menu-icon"></i>
                        <p>Help & Support</p>
                        <i class="fas fa-chevron-right arrow-icon"></i>
                    </a>
                <?php else : ?>
                    <a class="sub-menu-link" href="profile.php">
                        <i class="fas fa-user-edit menu-icon"></i>
                        <p>Edit Profile</p>
                        <i class="fas fa-chevron-right arrow-icon"></i>
                    </a>

                    <a class="sub-menu-link" href="settings.php">
                        <i class="fas fa-cog menu-icon"></i>
                        <p>Settings</p>
                        <i class="fas fa-chevron-right arrow-icon"></i>
                    </a>

                    <a class="sub-menu-link" href="privacy.php">
                        <i class="fas fa-shield-alt menu-icon"></i>
                        <p>Privacy & Security</p>
                        <i class="fas fa-chevron-right arrow-icon"></i>
                    </a>

                    <a class="sub-menu-link" href="help.php">
                        <i class="fas fa-question-circle menu-icon"></i>
                        <p>Help & Support</p>
                        <i class="fas fa-chevron-right arrow-icon"></i>
                    </a>

                    <hr class="menu-divider">

                    <a class="sub-menu-link logout-link" href="../logout.php">
                        <i class="fas fa-sign-out-alt menu-icon"></i>
                        <p>Logout</p>
                        <i class="fas fa-chevron-right arrow-icon"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle">
        <span></span>
        <span></span>
        <span></span>
    </button>
</div>
</div>
</div>
</header>

<div class="mobile-menu" id="mobileMenu">
    <ul class="mobile-nav-links">
        <li><a href="dashboard.php" class="mobile-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>"><i class="fas fa-home"></i> Dashboard</a></li>
        <li><a href="books.php" class="mobile-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'books.php' ? 'active' : ''; ?>"><i class="fas fa-book"></i> Books</a></li>
        <li><a href="members.php" class="mobile-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'members.php' ? 'active' : ''; ?>"><i class="fas fa-users"></i> Members</a></li>
        <li><a href="reports.php" class="mobile-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>"><i class="fas fa-chart-bar"></i> Reports</a></li>
        <?php if (!$is_guest): ?>
        <li><a href="settings.php" class="mobile-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>"><i class="fas fa-cog"></i> Settings</a></li>
        <?php endif; ?>
        <li><a href="help.php" class="mobile-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'help.php' ? 'active' : ''; ?>"><i class="fas fa-question-circle"></i> Help</a></li>
    </ul>

    <div class="mobile-menu-actions">
        <!-- User Info Section -->
        <div class="user-info">
            
      <div class="user-avatar">
                        <?php if (!$is_guest && !empty($current_user['profile_pic'])): ?>
                    <img src="<?php echo htmlspecialchars($current_user['profile_pic']); ?>" alt="Profile" class="user-avatar-img">
                <?php elseif (!$is_guest): ?>
                    <img src="<?php echo $current_user['avatar_url']; ?>" alt="Profile" class="user-avatar-img">
                <?php else : ?>
                    <i class="fas fa-user-circle user-icon-large  user-avatar-fix"></i>
                <?php endif; ?>
      </div>
            
            <div class="user-details">
                <h3><?php echo htmlspecialchars($current_user['first_name'] . ' ' . $current_user['last_name']); ?></h3>
                <p class="user-role">
                    <?php echo getRoleDisplayName($current_user['role_name'] ?? 'guest'); ?>
                </p>
            </div>
            <button class="btn btn-primary kebab-menu" id="openModal">
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </button>
        </div>

        <!-- Mobile Theme Toggle -->
        <button class="theme-toggle" id="mobileThemeToggle">
            <i class="fas fa-moon"></i>
            <span class="theme-text">Dark Mode</span>
        </button>

        <?php if ($is_guest): ?>
            <a href="../login.php" class="mobile-nav-link menu-logout redirect-link"><i class="fas fa-sign-in-alt"></i> Login</a>
            <a href="../register.php" class="mobile-nav-link menu-logout redirect-link"><i class="fas fa-user-plus"></i> Register</a>
        <?php else : ?>
            <a href="../logout.php" class="mobile-nav-link menu-logout redirect-link" style="color: #FF3233;"><i class="fas fa-sign-out-alt"></i> Logout</a>
        <?php endif; ?>
    </div>
</div>

<div class="overlay" id="overlay"></div>

<!-- Modal -->
<div class="modal-overlay" id="modalOverlay">
    <div class="modal">
        <div class="modal-header mobile-menu-actions">
            <div class="user-info">
                <div class="user-avatar">
                    <?php if (!$is_guest && !empty($current_user['profile_pic'])): ?>
                        <img src="<?php echo htmlspecialchars($current_user['profile_pic']); ?>" alt="Profile" class="user-avatar-img">
                    <?php elseif (!$is_guest): ?>
                        <img src="<?php echo $current_user['avatar_url']; ?>" alt="Profile" class="user-avatar-img">
                    <?php else : ?>
                        <i class="fas fa-user-circle user-icon"></i>
                    <?php endif; ?>
                </div>
                <div class="user-details">
                    <h3><?php echo htmlspecialchars($current_user['first_name'] . ' ' . $current_user['last_name']); ?></h3>
                    <p class="user-role">
                        <?php echo getRoleDisplayName($current_user['role_name'] ?? 'guest'); ?>
                    </p>
                </div>
                <button class="modal-close" id="closeModal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
        <div class="modal-body">
            <?php if ($is_guest): ?>
                <a class="sub-menu-link" href="../login.php">
                    <i class="fas fa-sign-in-alt menu-icon"></i>
                    <p>Login</p>
                    <i class="fas fa-chevron-right arrow-icon"></i>
                </a>
                <a class="sub-menu-link" href="../register.php">
                    <i class="fas fa-user-plus menu-icon"></i>
                    <p>Register</p>
                    <i class="fas fa-chevron-right arrow-icon"></i>
                </a>

                <hr class="menu-divider">

                <a class="sub-menu-link" href="help.php">
                    <i class="fas fa-question-circle menu-icon"></i>
                    <p>Help & Support</p>
                    <i class="fas fa-chevron-right arrow-icon"></i>
                </a>
            <?php else : ?>
                <a class="sub-menu-link" href="profile.php">
                    <i class="fas fa-user-edit menu-icon"></i>
                    <p>Edit Profile</p>
                    <i class="fas fa-chevron-right arrow-icon"></i>
                </a>

                <a class="sub-menu-link" href="settings.php">
                    <i class="fas fa-cog menu-icon"></i>
                    <p>Settings</p>
                    <i class="fas fa-chevron-right arrow-icon"></i>
                </a>

                <a class="sub-menu-link" href="privacy.php">
                    <i class="fas fa-shield-alt menu-icon"></i>
                    <p>Privacy & Security</p>
                    <i class="fas fa-chevron-right arrow-icon"></i>
                </a>

                <a class="sub-menu-link" href="help.php">
                    <i class="fas fa-question-circle menu-icon"></i>
                    <p>Help & Support</p>
                    <i class="fas fa-chevron-right arrow-icon"></i>
                </a>

                <hr class="menu-divider">

                <a class="sub-menu-link logout-link" href="../logout.php">
                    <i class="fas fa-sign-out-alt menu-icon"></i>
                    <p>Logout</p>
                    <i class="fas fa-chevron-right arrow-icon"></i>
                </a>
            <?php endif; ?>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" id="cancelModal">Cancel</button>
        </div>
    </div>
</div>

<!-- Add the missing JavaScript files -->
<script src="../assets/js/index.js" charset="utf-8" defer></script>
<script src="../assets/js/modal.js" charset="utf-8" defer></script>
<script src="../assets/js/form.js" charset="utf-8" defer></script>

<script>
// Dark mode functionality
document.addEventListener('DOMContentLoaded', function() {
    const themeToggle = document.getElementById('themeToggle');
    const mobileThemeToggle = document.getElementById('mobileThemeToggle');
    
    // Load saved theme or default to light
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeToggle(savedTheme);
    
    function toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateThemeToggle(newTheme);
    }
    
    function updateThemeToggle(theme) {
        const themeTexts = document.querySelectorAll('.theme-text');
        const themeIcons = document.querySelectorAll('.theme-toggle i');
        
        themeTexts.forEach(text => {
            text.textContent = theme === 'dark' ? 'Light Mode' : 'Dark Mode';
        });
        
        themeIcons.forEach(icon => {
            icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        });
    }
    
    // Event listeners
    if (themeToggle) themeToggle.addEventListener('click', toggleTheme);
    if (mobileThemeToggle) mobileThemeToggle.addEventListener('click', toggleTheme);
});
const modalOverlay = document.getElementById('modalOverlay');
const openModalBtn = document.getElementById('openModal');
const closeModalBtn = document.getElementById('closeModal');
const cancelModalBtn = document.getElementById('cancelModal');

const droplinks = document.querySelectorAll('.sub-menu-link');

openModalBtn.addEventListener('click', () => {
    modalOverlay.classList.add('active');
});

closeModalBtn.addEventListener('click', () => {
    modalOverlay.classList.remove('active');
});

cancelModalBtn.addEventListener('click', () => {
    modalOverlay.classList.remove('active');
});

droplinks.forEach(link => {
    link.addEventListener('click', () => {
        modalOverlay.classList.remove('active');
    });
});

modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) {
        modalOverlay.classList.remove('active');
    }
});
    // Global variable for base path
    const BASE_PATH = '<?php echo $base_path; ?>';
</script>