<?php
require_once 'config.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: books.php');
    exit();
}

$book_id = intval($_GET['id']);
$book = null;
$can_borrow = false;
$can_reserve = false;
$is_guest = !isLoggedIn();
$current_user_id = isLoggedIn() ? $_SESSION['user_id'] : null;

try {
    // Get book details with additional information
    $stmt = $pdo->prepare("
        SELECT b.*, s.name as supplier_name, 
               GROUP_CONCAT(DISTINCT c.name) as categories,
               GROUP_CONCAT(DISTINCT c.id) as category_ids,
               bar.allowed_roles, bar.borrow_limit_days, bar.max_renewals,
               bar.reservation_allowed, bar.requires_payment, bar.payment_amount
        FROM books b 
        LEFT JOIN suppliers s ON b.supplier_id = s.id
        LEFT JOIN book_categories bc ON b.id = bc.book_id
        LEFT JOIN categories c ON bc.category_id = c.id
        LEFT JOIN book_access_rules bar ON b.id = bar.book_id
        WHERE b.id = ? AND b.status = 'active'
        GROUP BY b.id
    ");
    $stmt->execute([$book_id]);
    $book = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$book) {
        die("Book not found");
    }
    
    // Check if user can access this book
    $can_access = canAccessBook($book, getUserRole());
    if (!$can_access) {
        die("You don't have permission to access this book");
    }
    
    // Check borrowing permissions
    if (isLoggedIn()) {
        $can_borrow = canBorrowBook($book, $_SESSION['user_id']);
        $can_reserve = canReserveBook($book, $_SESSION['user_id']);
    }
    
    // Get related books
    $related_books = getRelatedBooks($book);
    
} catch (Exception $e) {
    die("Error loading book details: " . $e->getMessage());
}

function canAccessBook($book, $user_role) {
    if ($book['access_type'] === 'public') {
        return true;
    }
    
    if ($user_role === ROLE_GUEST) {
        return false;
    }
    
    if ($book['access_type'] === 'registered') {
        return true;
    }
    
    if ($book['access_type'] === 'educational') {
        return in_array($user_role, [ROLE_STUDENT, ROLE_TEACHER, ROLE_LIBRARIAN, ROLE_ADMIN]);
    }
    
    return false;
}

function canBorrowBook($book, $user_id) {
    global $pdo;
    
    if ($book['available_copies'] <= 0) {
        return false;
    }
    
    // Check if user already has this book borrowed
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM borrow_transactions 
        WHERE user_id = ? AND book_id = ? AND status IN ('active', 'approved')
    ");
    $stmt->execute([$user_id, $book['id']]);
    $already_borrowed = $stmt->fetchColumn() > 0;
    
    return !$already_borrowed;
}

function canReserveBook($book, $user_id) {
    global $pdo;
    
    if ($book['available_copies'] > 0) {
        return false; // Don't reserve if copies are available
    }
    
    if (!$book['reservation_allowed']) {
        return false;
    }
    
    // Check if user already has this book reserved
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM borrow_transactions 
        WHERE user_id = ? AND book_id = ? AND status = 'pending' AND transaction_type = 'reserve'
    ");
    $stmt->execute([$user_id, $book['id']]);
    $already_reserved = $stmt->fetchColumn() > 0;
    
    return !$already_reserved;
}

function getRelatedBooks($book) {
    global $pdo;
    
    $category_ids = $book['category_ids'] ? explode(',', $book['category_ids']) : [];
    
    if (empty($category_ids)) {
        return [];
    }
    
    $placeholders = str_repeat('?,', count($category_ids) - 1) . '?';
    
    $stmt = $pdo->prepare("
        SELECT DISTINCT b.id, b.title, b.author, b.cover_image, b.available_copies
        FROM books b
        JOIN book_categories bc ON b.id = bc.book_id
        WHERE bc.category_id IN ($placeholders)
        AND b.id != ?
        AND b.status = 'active'
        AND b.available_copies > 0
        LIMIT 4
    ");
    
    $params = array_merge($category_ids, [$book['id']]);
    $stmt->execute($params);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($book['title']); ?> - Sabian Library</title>
    
    <!-- Include CSS files -->
    <link rel="stylesheet" href="assets/css/variables.css">
    <link rel="stylesheet" href="assets/css/reset.css">
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/utilities.css">
    <link rel="stylesheet" href="assets/css/forms.css">
    <link rel="stylesheet" href="assets/css/buttons.css">
    <link rel="stylesheet" href="assets/css/cards.css">
    <link rel="stylesheet" href="assets/css/badges.css">
    <link rel="stylesheet" href="assets/css/dark-mode.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .book-detail-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 20px;
        }
        
        .book-detail-content {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 3rem;
            margin-bottom: 3rem;
        }
        
        .book-cover-section {
            position: sticky;
            top: 2rem;
            height: fit-content;
        }
        
        .book-cover {
            width: 100%;
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
            margin-bottom: 1.5rem;
        }
        
        .book-cover-placeholder {
            width: 100%;
            height: 400px;
            background: var(--grey-100);
            border-radius: var(--radius);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 4rem;
            color: var(--grey-400);
            margin-bottom: 1.5rem;
        }
        
        .book-actions {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .book-info-section {
            padding: 1rem 0;
        }
        
        .book-title {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            color: var(--grey-900);
            line-height: 1.2;
        }
        
        .book-author {
            font-size: 1.3rem;
            color: var(--grey-600);
            margin-bottom: 2rem;
        }
        
        .book-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
            padding: 1.5rem;
            background: var(--grey-50);
            border-radius: var(--radius);
        }
        
        .meta-item {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .meta-label {
            font-weight: 600;
            color: var(--grey-700);
            font-size: 0.9rem;
        }
        
        .meta-value {
            color: var(--grey-800);
        }
        
        .book-description {
            margin-bottom: 2rem;
            line-height: 1.7;
        }
        
        .book-description h3 {
            margin-bottom: 1rem;
            color: var(--grey-800);
        }
        
        .related-books {
            margin-top: 3rem;
        }
        
        .related-books h2 {
            margin-bottom: 1.5rem;
            color: var(--grey-800);
        }
        
        .related-books-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
        }
        
        .related-book-card {
            background: #fff;
            border-radius: var(--radius);
            padding: 1rem;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            text-decoration: none;
            color: inherit;
        }
        
        .related-book-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }
        
        .related-book-cover {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: var(--radius);
            margin-bottom: 1rem;
        }
        
        .related-book-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
            line-height: 1.3;
        }
        
        .related-book-author {
            color: var(--grey-600);
            font-size: 0.85rem;
        }
        
        .availability-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
            margin-bottom: 1rem;
        }
        
        .available {
            background: rgba(34, 197, 94, 0.1);
            color: #16a34a;
        }
        
        .unavailable {
            background: rgba(239, 68, 68, 0.1);
            color: #dc2626;
        }
        
        .limited {
            background: rgba(245, 158, 11, 0.1);
            color: #d97706;
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        @media (max-width: 768px) {
            .book-detail-content {
                grid-template-columns: 1fr;
                gap: 2rem;
            }
            
            .book-cover-section {
                position: static;
            }
            
            .book-cover {
                max-width: 250px;
                margin: 0 auto 1.5rem;
            }
            
            .book-meta {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
        
        [data-theme="dark"] .book-meta {
            background: var(--dark-3);
        }
        
        [data-theme="dark"] .related-book-card {
            background: var(--dark-2);
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="book-detail-container">
        <div class="book-detail-content">
            <!-- Book Cover Section -->
            <div class="book-cover-section">
                <?php if ($book['cover_image']): ?>
                    <img src="<?php echo htmlspecialchars($book['cover_image']); ?>" 
                         alt="<?php echo htmlspecialchars($book['title']); ?>" 
                         class="book-cover">
                <?php else: ?>
                    <div class="book-cover-placeholder">
                        <i class="fas fa-book"></i>
                    </div>
                <?php endif; ?>
                
                <!-- Availability Status -->
                <div class="availability-badge <?php echo $book['available_copies'] > 0 ? 'available' : 'unavailable'; ?>">
                    <i class="fas fa-<?php echo $book['available_copies'] > 0 ? 'check-circle' : 'times-circle'; ?>"></i>
                    <?php echo $book['available_copies'] > 0 ? 'Available' : 'Out of Stock'; ?>
                    (<?php echo $book['available_copies']; ?>/<?php echo $book['total_copies']; ?>)
                </div>
                
                <!-- Action Buttons -->
                <div class="book-actions">
                    <?php if (!$is_guest && $can_borrow): ?>
                        <button class="btn btn-primary btn-lg" onclick="borrowBook(<?php echo $book['id']; ?>)">
                            <i class="fas fa-bookmark"></i> Borrow Book
                        </button>
                    <?php elseif (!$is_guest && $can_reserve): ?>
                        <button class="btn btn-warning btn-lg" onclick="reserveBook(<?php echo $book['id']; ?>)">
                            <i class="fas fa-clock"></i> Reserve Book
                        </button>
                    <?php elseif ($is_guest): ?>
                        <a href="login.php" class="btn btn-primary btn-lg">
                            <i class="fas fa-sign-in-alt"></i> Login to Access
                        </a>
                    <?php else: ?>
                        <button class="btn btn-disabled btn-lg" disabled>
                            <i class="fas fa-ban"></i> Not Available
                        </button>
                    <?php endif; ?>
                    
                    <?php if ($book['is_digital'] && !$is_guest): ?>
                    <div class="action-buttons">
                        <button class="btn btn-outline" onclick="readOnline(<?php echo $book['id']; ?>)">
                            <i class="fas fa-eye"></i> Read Online
                        </button>
                        
                        <?php if (in_array(getUserRole(), [ROLE_ADMIN, ROLE_LIBRARIAN])): ?>
                        <button class="btn btn-outline" onclick="downloadBook(<?php echo $book['id']; ?>)">
                            <i class="fas fa-download"></i> Download
                        </button>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Book Information Section -->
            <div class="book-info-section">
                <h1 class="book-title"><?php echo htmlspecialchars($book['title']); ?></h1>
                <p class="book-author">by <?php echo htmlspecialchars($book['author']); ?></p>
                
                <!-- Book Metadata -->
                <div class="book-meta">
                    <div class="meta-item">
                        <span class="meta-label">Access Type</span>
                        <span class="badge badge-<?php echo $book['access_type']; ?>">
                            <?php echo ucfirst($book['access_type']); ?>
                        </span>
                    </div>
                    
                    <div class="meta-item">
                        <span class="meta-label">ISBN</span>
                        <span class="meta-value"><?php echo $book['isbn'] ? htmlspecialchars($book['isbn']) : 'N/A'; ?></span>
                    </div>
                    
                    <div class="meta-item">
                        <span class="meta-label">Publisher</span>
                        <span class="meta-value"><?php echo $book['publisher'] ? htmlspecialchars($book['publisher']) : 'N/A'; ?></span>
                    </div>
                    
                    <div class="meta-item">
                        <span class="meta-label">Publication Year</span>
                        <span class="meta-value"><?php echo $book['publication_year'] ? htmlspecialchars($book['publication_year']) : 'N/A'; ?></span>
                    </div>
                    
                    <div class="meta-item">
                        <span class="meta-label">Language</span>
                        <span class="meta-value"><?php echo $book['language'] ? htmlspecialchars($book['language']) : 'English'; ?></span>
                    </div>
                    
                    <div class="meta-item">
                        <span class="meta-label">Pages</span>
                        <span class="meta-value"><?php echo $book['page_count'] ? htmlspecialchars($book['page_count']) : 'N/A'; ?></span>
                    </div>
                    
                    <?php if ($book['categories']): ?>
                    <div class="meta-item">
                        <span class="meta-label">Categories</span>
                        <span class="meta-value"><?php echo htmlspecialchars($book['categories']); ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($book['supplier_name']): ?>
                    <div class="meta-item">
                        <span class="meta-label">Supplier</span>
                        <span class="meta-value"><?php echo htmlspecialchars($book['supplier_name']); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Book Description -->
                <div class="book-description">
                    <h3>Description</h3>
                    <p><?php echo nl2br(htmlspecialchars($book['description'] ?: 'No description available.')); ?></p>
                </div>
                
                <!-- Borrowing Information -->
                <?php if ($book['borrow_limit_days']): ?>
                <div class="book-description">
                    <h3>Borrowing Information</h3>
                    <div class="book-meta">
                        <div class="meta-item">
                            <span class="meta-label">Borrow Period</span>
                            <span class="meta-value"><?php echo $book['borrow_limit_days']; ?> days</span>
                        </div>
                        
                        <div class="meta-item">
                            <span class="meta-label">Max Renewals</span>
                            <span class="meta-value"><?php echo $book['max_renewals'] ?: 0; ?></span>
                        </div>
                        
                        <?php if ($book['requires_payment']): ?>
                        <div class="meta-item">
                            <span class="meta-label">Rental Fee</span>
                            <span class="meta-value">$<?php echo number_format($book['payment_amount'], 2); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Related Books Section -->
        <?php if (!empty($related_books)): ?>
        <div class="related-books">
            <h2>Related Books</h2>
            <div class="related-books-grid">
                <?php foreach ($related_books as $related_book): ?>
                    <a href="book_details.php?id=<?php echo $related_book['id']; ?>" class="related-book-card">
                        <?php if ($related_book['cover_image']): ?>
                            <img src="<?php echo htmlspecialchars($related_book['cover_image']); ?>" 
                                 alt="<?php echo htmlspecialchars($related_book['title']); ?>" 
                                 class="related-book-cover">
                        <?php else: ?>
                            <div style="height: 150px; background: var(--grey-100); border-radius: var(--radius); display: flex; align-items: center; justify-content: center; margin-bottom: 1rem;">
                                <i class="fas fa-book" style="font-size: 2rem; color: var(--grey-400);"></i>
                            </div>
                        <?php endif; ?>
                        <div class="related-book-title"><?php echo htmlspecialchars($related_book['title']); ?></div>
                        <div class="related-book-author">by <?php echo htmlspecialchars($related_book['author']); ?></div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script>
    function borrowBook(bookId) {
        if (confirm('Are you sure you want to borrow this book?')) {
            fetch('includes/borrow-book.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'book_id=' + bookId + '&action=borrow'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Book borrowed successfully!');
                    location.reload();
                } else {
                    alert('Error: ' + data.error);
                }
            })
            .catch(error => {
                alert('Error borrowing book');
            });
        }
    }
    
    function reserveBook(bookId) {
        if (confirm('Are you sure you want to reserve this book? You will be notified when it becomes available.')) {
            fetch('includes/borrow-book.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'book_id=' + bookId + '&action=reserve'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Book reserved successfully!');
                    location.reload();
                } else {
                    alert('Error: ' + data.error);
                }
            })
            .catch(error => {
                alert('Error reserving book');
            });
        }
    }
    
    function readOnline(bookId) {
        window.open('read-book.php?id=' + bookId, '_blank');
    }
    
    function downloadBook(bookId) {
        window.location.href = 'download-book.php?id=' + bookId;
    }
    </script>
</body>
</html>