<?php
require_once 'config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: search.php');
    exit();
}

$user_id = intval($_GET['id']);
$user = null;
$current_user_role = getUserRole();
$is_admin = in_array($current_user_role, [ROLE_ADMIN, ROLE_LIBRARIAN]);

try {
    // Get user details based on viewer's role
    if ($is_admin) {
        // Admin can see full details
        $stmt = $pdo->prepare("
            SELECT u.*, ur.role_name, ur.access_level
            FROM users u 
            JOIN user_roles ur ON u.role_id = ur.id
            WHERE u.id = ?
        ");
    } else {
        // Regular users see limited info
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.first_name, u.last_name, 
                   u.profile_pic, ur.role_name, u.membership_status,
                   u.created_at
            FROM users u 
            JOIN user_roles ur ON u.role_id = ur.id
            WHERE u.id = ? AND u.membership_status = 'active'
        ");
    }
    
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        die("User not found");
    }
    
    // Get user statistics (only for admin or self-view)
    $user_stats = [];
    if ($is_admin || $user_id == $_SESSION['user_id']) {
        $stmt = $pdo->prepare("
            SELECT 
                COUNT(CASE WHEN status IN ('active', 'approved') THEN 1 END) as borrowed_books,
                COUNT(CASE WHEN status = 'pending' AND transaction_type = 'reserve' THEN 1 END) as reserved_books,
                COUNT(CASE WHEN status = 'overdue' THEN 1 END) as overdue_books,
                COALESCE(SUM(CASE WHEN f.status = 'unpaid' THEN f.amount ELSE 0 END), 0) as total_fines
            FROM borrow_transactions bt
            LEFT JOIN fines f ON bt.id = f.transaction_id
            WHERE bt.user_id = ?
        ");
        $stmt->execute([$user_id]);
        $user_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
} catch (Exception $e) {
    die("Error loading user details: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?> - Sabian Library</title>
    
    <!-- Include CSS files -->
    <link rel="stylesheet" href="assets/css/variables.css">
    <link rel="stylesheet" href="assets/css/reset.css">
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/utilities.css">
    <link rel="stylesheet" href="assets/css/forms.css">
    <link rel="stylesheet" href="assets/css/buttons.css">
    <link rel="stylesheet" href="assets/css/cards.css">
    <link rel="stylesheet" href="assets/css/badges.css">
    <link rel="stylesheet" href="assets/css/dark-mode.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .user-preview-container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 0 20px;
        }
        
        .user-profile-card {
            background: #fff;
            border-radius: var(--radius);
            padding: 2rem;
            box-shadow: var(--shadow-sm);
            margin-bottom: 2rem;
        }
        
        .user-profile-header {
            display: flex;
            align-items: center;
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        .user-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: var(--color-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
            font-weight: bold;
            flex-shrink: 0;
            overflow: hidden;
        }
        
        .user-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-info h1 {
            margin-bottom: 0.5rem;
            color: var(--grey-900);
        }
        
        .user-role {
            display: inline-block;
            padding: 0.5rem 1rem;
            background: var(--color-primary);
            color: white;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .user-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: var(--grey-50);
            padding: 1.5rem;
            border-radius: var(--radius);
            text-align: center;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--color-primary);
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: var(--grey-600);
            font-size: 0.9rem;
        }
        
        .user-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .detail-group {
            padding: 1rem 0;
        }
        
        .detail-label {
            font-weight: 600;
            color: var(--grey-700);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        
        .detail-value {
            color: var(--grey-800);
        }
        
        .limited-access-notice {
            background: var(--warning);
            color: var(--grey-900);
            padding: 1rem;
            border-radius: var(--radius);
            margin: 2rem 0;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .admin-actions {
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid var(--grey-200);
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        .membership-status {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: var(--radius);
            font-weight: 600;
            margin-left: 1rem;
        }
        
        .status-active {
            background: rgba(34, 197, 94, 0.1);
            color: #16a34a;
        }
        
        .status-inactive {
            background: rgba(239, 68, 68, 0.1);
            color: #dc2626;
        }
        
        .status-suspended {
            background: rgba(245, 158, 11, 0.1);
            color: #d97706;
        }
        
        @media (max-width: 768px) {
            .user-profile-header {
                flex-direction: column;
                text-align: center;
            }
            
            .user-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
        
        [data-theme="dark"] .user-profile-card {
            background: var(--dark-2);
        }
        
        [data-theme="dark"] .stat-card {
            background: var(--dark-3);
        }
        
        [data-theme="dark"] .limited-access-notice {
            background: rgba(234, 179, 8, 0.2);
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="user-preview-container">
        <div class="user-profile-card">
            <!-- User Profile Header -->
            <div class="user-profile-header">
                <div class="user-avatar">
                    <?php if ($user['profile_pic']): ?>
                        <img src="<?php echo htmlspecialchars($user['profile_pic']); ?>" alt="Profile Picture">
                    <?php else: ?>
                        <?php echo strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1)); ?>
                    <?php endif; ?>
                </div>
                
                <div class="user-info">
                    <h1><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h1>
                    <div class="user-role"><?php echo ucfirst($user['role_name']); ?></div>
                    
                    <div class="membership-status <?php echo 'status-' . $user['membership_status']; ?>">
                        <i class="fas fa-<?php echo $user['membership_status'] === 'active' ? 'check-circle' : ($user['membership_status'] === 'suspended' ? 'exclamation-triangle' : 'times-circle'); ?>"></i>
                        <?php echo ucfirst($user['membership_status']); ?> Member
                    </div>
                    
                    <?php if ($user_id == $_SESSION['user_id']): ?>
                        <p style="color: var(--grey-600); margin-top: 1rem;">
                            <i class="fas fa-info-circle"></i> This is your profile
                        </p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- User Statistics (Admin or self-view only) -->
            <?php if ($is_admin || $user_id == $_SESSION['user_id']): ?>
            <div class="user-stats">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $user_stats['borrowed_books'] ?? 0; ?></div>
                    <div class="stat-label">Books Borrowed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $user_stats['reserved_books'] ?? 0; ?></div>
                    <div class="stat-label">Books Reserved</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?php echo $user_stats['overdue_books'] ?? 0; ?></div>
                    <div class="stat-label">Overdue Books</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">$<?php echo number_format($user_stats['total_fines'] ?? 0, 2); ?></div>
                    <div class="stat-label">Outstanding Fines</div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- User Details -->
            <div class="user-details">
                <?php if ($is_admin): ?>
                    <!-- Full details for admin -->
                    <div class="detail-group">
                        <div class="detail-label">Username</div>
                        <div class="detail-value"><?php echo htmlspecialchars($user['username']); ?></div>
                    </div>
                    
                    <div class="detail-group">
                        <div class="detail-label">Email</div>
                        <div class="detail-value"><?php echo htmlspecialchars($user['email']); ?></div>
                    </div>
                    
                    <?php if (!empty($user['school_id'])): ?>
                    <div class="detail-group">
                        <div class="detail-label">School ID</div>
                        <div class="detail-value"><?php echo htmlspecialchars($user['school_id']); ?></div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($user['phone'])): ?>
                    <div class="detail-group">
                        <div class="detail-label">Phone</div>
                        <div class="detail-value"><?php echo htmlspecialchars($user['phone']); ?></div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="detail-group">
                        <div class="detail-label">Access Level</div>
                        <div class="detail-value"><?php echo $user['access_level']; ?></div>
                    </div>
                    
                    <div class="detail-group">
                        <div class="detail-label">Member Since</div>
                        <div class="detail-value"><?php echo date('F j, Y', strtotime($user['created_at'])); ?></div>
                    </div>
                    
                    <div class="detail-group">
                        <div class="detail-label">Last Login</div>
                        <div class="detail-value">
                            <?php echo $user['last_login'] ? date('F j, Y g:i A', strtotime($user['last_login'])) : 'Never'; ?>
                        </div>
                    </div>
                    
                <?php else: ?>
                    <!-- Limited details for regular users -->
                    <div class="detail-group">
                        <div class="detail-label">Role</div>
                        <div class="detail-value"><?php echo ucfirst($user['role_name']); ?></div>
                    </div>
                    
                    <div class="detail-group">
                        <div class="detail-label">Member Since</div>
                        <div class="detail-value"><?php echo date('F j, Y', strtotime($user['created_at'])); ?></div>
                    </div>
                    
                    <div class="detail-group">
                        <div class="detail-label">Status</div>
                        <div class="detail-value"><?php echo ucfirst($user['membership_status']); ?></div>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Limited Access Notice for non-admin viewing other users -->
            <?php if (!$is_admin && $user_id != $_SESSION['user_id']): ?>
            <div class="limited-access-notice">
                <i class="fas fa-info-circle"></i>
                <div>
                    <strong>Limited Profile View</strong>
                    <p style="margin: 0.5rem 0 0 0; font-size: 0.9rem;">
                        Contact library staff for more information about this user.
                    </p>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Admin Actions -->
            <?php if ($is_admin && $user_id != $_SESSION['user_id']): ?>
            <div class="admin-actions">
                <h3 style="margin-bottom: 1rem;">Admin Actions</h3>
                <div class="action-buttons">
                    <a href="admin/edit-user.php?id=<?php echo $user['id']; ?>" class="btn btn-primary">
                        <i class="fas fa-edit"></i> Edit User
                    </a>
                    
                    <?php if ($user['membership_status'] === 'active'): ?>
                        <button class="btn btn-warning" onclick="suspendUser(<?php echo $user['id']; ?>)">
                            <i class="fas fa-pause"></i> Suspend
                        </button>
                    <?php elseif ($user['membership_status'] === 'suspended'): ?>
                        <button class="btn btn-success" onclick="activateUser(<?php echo $user['id']; ?>)">
                            <i class="fas fa-play"></i> Activate
                        </button>
                    <?php endif; ?>
                    
                    <button class="btn btn-danger" onclick="deleteUser(<?php echo $user['id']; ?>)">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
    function suspendUser(userId) {
        if (confirm('Are you sure you want to suspend this user?')) {
            // Implement suspend functionality
            alert('Suspend functionality would be implemented here.');
        }
    }
    
    function activateUser(userId) {
        if (confirm('Are you sure you want to activate this user?')) {
            // Implement activate functionality
            alert('Activate functionality would be implemented here.');
        }
    }
    
    function deleteUser(userId) {
        if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
            // Implement delete functionality
            alert('Delete functionality would be implemented here.');
        }
    }
    </script>
</body>
</html>