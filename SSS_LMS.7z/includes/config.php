<?php
session_start();

define('BASE_DIR', dirname(__DIR__));
define('DB_DIR', BASE_DIR . '/includes');
define('DB_FILE', DB_DIR . '/database.db');
define('MAX_FILE_SIZE', 10 * 1024 * 1024); 
define('ALLOWED_BOOK_TYPES', ['application/pdf']);
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);
define('UPLOAD_DIR', __DIR__ . '/../uploads/');

try {
    // Check if database directory and file exist
    if (!is_dir(DB_DIR)) {
        throw new PDOException("Database directory does not exist: " . DB_DIR);
    }
    
    if (!file_exists(DB_FILE)) {
        throw new PDOException("Database file does not exist. Please run init_db.php first.");
    }
    
    if (!is_writable(DB_FILE)) {
        throw new PDOException("Database file is not writable.");
    }

    $db = new PDO('sqlite:' . DB_FILE);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec("PRAGMA foreign_keys = ON");
    
    // Create a $pdo variable that references the same connection
    $pdo = $db;
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage() . 
        "<br>Please make sure the database is properly initialized by running init_db.php");
}

// Role constants for easy reference
define('ROLE_ADMIN', 1);
define('ROLE_LIBRARIAN', 2);
define('ROLE_TEACHER', 3);
define('ROLE_STUDENT', 4);
define('ROLE_REGULAR', 5);

// Function to get dashboard URL based on role
function getDashboardByRole($roleId) {
    switch ($roleId) {
        case ROLE_ADMIN:
            return '/admin/admin_dashboard.php';
        case ROLE_LIBRARIAN:
            return '/librarian/librarian_dashboard.php';
        case ROLE_TEACHER:
            return '/teacher/teacher_dashboard.php';
        case ROLE_STUDENT:
            return '/student/student_dashboard.php';
        case ROLE_REGULAR:
            return '/regular/regular_dashboard.php';
        default:
            return '/dashboard.php';
    }
}

// Updated helper functions for role-based access
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getUserRole() {
    return $_SESSION['role_id'] ?? ROLE_REGULAR;
}

function isAdmin() {
    return isLoggedIn() && getUserRole() === ROLE_ADMIN;
}

function isLibrarian() {
    return isLoggedIn() && getUserRole() === ROLE_LIBRARIAN;
}

function isTeacher() {
    return isLoggedIn() && getUserRole() === ROLE_TEACHER;
}

function isStudent() {
    return isLoggedIn() && getUserRole() === ROLE_STUDENT;
}

function isRegular() {
    return isLoggedIn() && getUserRole() === ROLE_REGULAR;
}

function hasPermission($requiredRole) {
    if (!isLoggedIn()) return false;
    
    $userRole = getUserRole();
    
    // Admin has all permissions
    if ($userRole === ROLE_ADMIN) return true;
    
    // Check if user has the required role or higher
    return $userRole <= $requiredRole;
}

function requireRole($requiredRole) {
    if (!hasPermission($requiredRole)) {
        header('HTTP/1.0 403 Forbidden');
        echo "You don't have permission to access this page.";
        exit();
    }
}

function requireAdmin() {
    requireRole(ROLE_ADMIN);
}

function requireLibrarian() {
    requireRole(ROLE_LIBRARIAN);
}

function requireTeacher() {
    requireRole(ROLE_TEACHER);
}

// File upload and utility functions
function validateFileUpload($file, $allowedTypes, $maxSize) {
    $errors = [];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = "File upload error";
        return $errors;
    }
    if ($file['size'] > $maxSize) {
        $errors[] = "File too large (max " . ($maxSize / 1024 / 1024) . "MB)";
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    
    if (!in_array($mime, $allowedTypes)) {
        $errors[] = "Invalid file type";
    }
    
    return $errors;
}

function secureDownload($filePath, $originalName) {
    if (!file_exists($filePath)) {
        return false;
    }
    
    $filePath = realpath($filePath);
    $baseDir = realpath(__DIR__ . '/uploads');
    
    if (strpos($filePath, $baseDir) !== 0) {
        return false;
    }
    header('Content-Description: File Transfer');
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . basename($originalName) . '.pdf"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($filePath));
    
    ob_clean();
    flush();
    
    readfile($filePath);
    return true;
}

function redirect($url, $statusCode = 303) {
    header("Location: $url", true, $statusCode);
    exit();
}
?>