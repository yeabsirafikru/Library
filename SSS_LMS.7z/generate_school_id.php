<?php
require_once 'includes/config.php';

// Only admin can access this page
requireAdmin();

$pageTitle = "Generate School ID";
require_once 'includes/header.php';

$message = '';
$error = '';
$generated_id = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role_type = $_POST['role_type'] ?? '';
    $quantity = intval($_POST['quantity'] ?? 1);
    $expiry_days = intval($_POST['expiry_days'] ?? 30);
    
    if (empty($role_type) || !in_array($role_type, ['student', 'teacher'])) {
        $error = 'Please select a valid role type';
    } elseif ($quantity < 1 || $quantity > 50) {
        $error = 'Quantity must be between 1 and 50';
    } elseif ($expiry_days < 1 || $expiry_days > 365) {
        $error = 'Expiry days must be between 1 and 365';
    } else {
        try {
            $generated_ids = [];
            
            for ($i = 0; $i < $quantity; $i++) {
                // Generate unique school ID
                do {
                    $prefix = strtoupper($role_type) == 'STUDENT' ? 'STU' : 'TCH';
                    $random_digits = str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
                    $school_id = $prefix . $random_digits;
                    
                    // Check if ID already exists
                    $stmt = $db->prepare("SELECT COUNT(*) FROM school_ids WHERE school_id = ?");
                    $stmt->execute([$school_id]);
                } while ($stmt->fetchColumn() > 0);
                
                // Calculate expiry date
                $expires_at = date('Y-m-d H:i:s', strtotime("+{$expiry_days} days"));
                
                // Insert into database
                $stmt = $db->prepare("INSERT INTO school_ids (school_id, role_type, generated_by, expires_at) VALUES (?, ?, ?, ?)");
                $stmt->execute([$school_id, $role_type, $_SESSION['user_id'], $expires_at]);
                
                $generated_ids[] = $school_id;
            }
            
            if ($quantity == 1) {
                $message = "School ID generated successfully: <strong>{$generated_ids[0]}</strong>";
                $generated_id = $generated_ids[0];
            } else {
                $message = "Generated {$quantity} school IDs successfully";
            }
            
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Get statistics
try {
    $stmt = $db->prepare("
        SELECT 
            role_type,
            COUNT(*) as total,
            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
            SUM(CASE WHEN status = 'used' THEN 1 ELSE 0 END) as used,
            SUM(CASE WHEN status = 'revoked' THEN 1 ELSE 0 END) as revoked
        FROM school_ids 
        GROUP BY role_type
    ");
    $stmt->execute();
    $stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $student_stats = [];
    $teacher_stats = [];
    foreach ($stats as $stat) {
        if ($stat['role_type'] == 'student') {
            $student_stats = $stat;
        } else {
            $teacher_stats = $stat;
        }
    }
    
} catch (PDOException $e) {
    $error = 'Error fetching statistics: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Id Generate</title>

  </head>
  <body>
<div class="container">
    <div class="page-header">
        <h1><i class="fas fa-id-card"></i> Generate School ID</h1>
        <p class="lead">Create student and teacher IDs for registration</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($message): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <div class="content-grid">
        <!-- Generation Form -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-plus-circle"></i> Generate New ID</h3>
            </div>
            <div class="card-body">
                <form method="POST" class="generation-form">
                    <div class="form-group">
                        <label for="role_type" class="form-label">Role Type</label>
                        <div class="role-buttons">
                            <button type="button" class="role-btn active" data-role="student">
                                <i class="fas fa-user-graduate"></i>
                                <span>Student ID</span>
                            </button>
                            <button type="button" class="role-btn" data-role="teacher">
                                <i class="fas fa-chalkboard-teacher"></i>
                                <span>Teacher ID</span>
                            </button>
                        </div>
                        <input type="hidden" name="role_type" id="role_type" value="student" required>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="quantity" class="form-label">Quantity</label>
                            <input type="number" class="input" id="quantity" name="quantity" 
                                   min="1" max="50" value="1" required>
                            <div class="form-hint">1-50 IDs at a time</div>
                        </div>
                        
                        <div class="form-group">
                            <label for="expiry_days" class="form-label">Expiry Days</label>
                            <input type="number" class="input" id="expiry_days" name="expiry_days" 
                                   min="1" max="365" value="30" required>
                            <div class="form-hint">Days until expiry</div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg btn-block">
                        <i class="fas fa-bolt"></i> Generate School ID(s)
                    </button>
                </form>
            </div>
        </div>

        <!-- Statistics -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-chart-bar"></i> Statistics</h3>
            </div>
            <div class="card-body">
                <div class="stats-grid">
                    <div class="stat-card student-stat">
                        <div class="stat-icon">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="stat-info">
                            <h4>Student IDs</h4>
                            <div class="stat-numbers">
                                <span class="total">Total: <?php echo $student_stats['total'] ?? 0; ?></span>
                                <span class="active">Active: <?php echo $student_stats['active'] ?? 0; ?></span>
                                <span class="used">Used: <?php echo $student_stats['used'] ?? 0; ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card teacher-stat">
                        <div class="stat-icon">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </div>
                        <div class="stat-info">
                            <h4>Teacher IDs</h4>
                            <div class="stat-numbers">
                                <span class="total">Total: <?php echo $teacher_stats['total'] ?? 0; ?></span>
                                <span class="active">Active: <?php echo $teacher_stats['active'] ?? 0; ?></span>
                                <span class="used">Used: <?php echo $teacher_stats['used'] ?? 0; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Generated ID Display -->
    <?php if ($generated_id): ?>
    <div class="card generated-id-card">
        <div class="card-header">
            <h3><i class="fas fa-check-circle text-success"></i> Generated ID</h3>
        </div>
        <div class="card-body">
            <div class="generated-id-display">
                <div class="id-preview">
                    <span class="id-prefix"><?php echo substr($generated_id, 0, 3); ?></span>
                    <span class="id-digits"><?php echo substr($generated_id, 3); ?></span>
                </div>
                <div class="id-info">
                    <p><strong>Role:</strong> <?php echo ucfirst($role_type); ?></p>
                    <p><strong>Expires:</strong> <?php echo date('M j, Y', strtotime("+{$expiry_days} days")); ?></p>
                </div>
                <button class="btn btn-outline copy-btn" data-id="<?php echo $generated_id; ?>">
                    <i class="fas fa-copy"></i> Copy ID
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Recent Generated IDs -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-history"></i> Recently Generated IDs</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>School ID</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Generated</th>
                            <th>Expires</th>
                            <th>Used By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        try {
                            $stmt = $db->prepare("
                                SELECT s.*, u.username as used_by_username 
                                FROM school_ids s 
                                LEFT JOIN users u ON s.used_by = u.id 
                                ORDER BY s.generated_at DESC 
                                LIMIT 10
                            ");
                            $stmt->execute();
                            $recent_ids = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            
                            if (empty($recent_ids)) {
                                echo '<tr><td colspan="6" class="text-center">No IDs generated yet</td></tr>';
                            } else {
                                foreach ($recent_ids as $id) {
                                    $status_class = '';
                                    switch ($id['status']) {
                                        case 'active': $status_class = 'badge-available'; break;
                                        case 'used': $status_class = 'badge-issued'; break;
                                        case 'revoked': $status_class = 'badge-lost'; break;
                                    }
                                    
                                    echo "
                                    <tr>
                                        <td><code>{$id['school_id']}</code></td>
                                        <td>" . ucfirst($id['role_type']) . "</td>
                                        <td><span class='badge {$status_class}'>{$id['status']}</span></td>
                                        <td>" . date('M j, Y', strtotime($id['generated_at'])) . "</td>
                                        <td>" . ($id['expires_at'] ? date('M j, Y', strtotime($id['expires_at'])) : 'Never') . "</td>
                                        <td>" . ($id['used_by_username'] ? $id['used_by_username'] : '-') . "</td>
                                    </tr>";
                                }
                            }
                        } catch (PDOException $e) {
                            echo '<tr><td colspan="6" class="text-center">Error loading recent IDs</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function() {
    // Role selection
    const roleButtons = document.querySelectorAll('.role-btn');
    const roleTypeInput = document.getElementById('role_type');
    
    roleButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const role = this.dataset.role;
            
            // Update active state
            roleButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Update hidden input
            roleTypeInput.value = role;
        });
    });
    
    // Copy to clipboard
    const copyBtn = document.querySelector('.copy-btn');
    if (copyBtn) {
        copyBtn.addEventListener('click', function() {
            const id = this.dataset.id;
            navigator.clipboard.writeText(id).then(() => {
                const originalHtml = this.innerHTML;
                this.innerHTML = '<i class="fas fa-check"></i> Copied!';
                this.classList.add('btn-success');
                
                setTimeout(() => {
                    this.innerHTML = originalHtml;
                    this.classList.remove('btn-success');
                }, 2000);
            });
        });
    }
    
    // Quantity validation
    const quantityInput = document.getElementById('quantity');
    quantityInput.addEventListener('change', function() {
        if (this.value < 1) this.value = 1;
        if (this.value > 50) this.value = 50;
    });
    
    // Expiry days validation
    const expiryInput = document.getElementById('expiry_days');
    expiryInput.addEventListener('change', function() {
        if (this.value < 1) this.value = 1;
        if (this.value > 365) this.value = 365;
    });
});
</script>
  
</body>
</html>