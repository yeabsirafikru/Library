<?php
// test_search.php - Simple direct test
echo "Testing search.php accessibility...<br>";

// Test if search.php exists
if (file_exists('search.php')) {
    echo "✓ search.php file exists<br>";
} else {
    echo "✗ search.php file NOT found<br>";
}

// Test direct access to search.php
$test_url = 'search.php?query=test';
echo "Testing URL: $test_url<br>";

$response = file_get_contents($test_url);
if ($response === FALSE) {
    echo "✗ Cannot access search.php<br>";
    echo "Error: " . error_get_last()['message'] . "<br>";
} else {
    echo "✓ search.php is accessible<br>";
    echo "Response: " . htmlspecialchars(substr($response, 0, 200)) . "...<br>";
}
?>