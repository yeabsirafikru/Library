<?php
require_once 'includes/config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: search.php');
    exit();
}

$user_id = intval($_GET['id']);
$user = null;
$current_user_role = getUserRole();
$is_admin = in_array($current_user_role, [ROLE_ADMIN, ROLE_LIBRARIAN]);

try {
    // Get user details based on viewer's role
    if ($is_admin) {
        // Admin can see full details
        $stmt = $pdo->prepare("
            SELECT u.*, ur.role_name, ur.access_level
            FROM users u 
            JOIN user_roles ur ON u.role_id = ur.id
            WHERE u.id = ?
        ");
    } else {
        // Regular users see limited info
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.first_name, u.last_name, 
                   u.profile_pic, ur.role_name, u.membership_status,
                   u.created_at
            FROM users u 
            JOIN user_roles ur ON u.role_id = ur.id
            WHERE u.id = ? AND u.membership_status = 'active'
        ");
    }
    
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        die("User not found");
    }
    
    // Get user statistics (only for admin or self-view)
    $user_stats = [];
    if ($is_admin || $user_id == $_SESSION['user_id']) {
        $stmt = $pdo->prepare("
            SELECT 
                COUNT(CASE WHEN bt.status IN ('active', 'approved') THEN 1 END) as borrowed_books,
                COUNT(CASE WHEN bt.status = 'pending' AND bt.transaction_type = 'reserve' THEN 1 END) as reserved_books,
                COUNT(CASE WHEN bt.status = 'overdue' THEN 1 END) as overdue_books,
                COALESCE(SUM(CASE WHEN f.status = 'unpaid' THEN f.amount ELSE 0 END), 0) as total_fines
            FROM borrow_transactions bt
            LEFT JOIN fines f ON bt.id = f.transaction_id
            WHERE bt.user_id = ?
        ");
        $stmt->execute([$user_id]);
        $user_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
} catch (Exception $e) {
    die("Error loading user details: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?> - Sabian Library</title>
    
    <!-- Include CSS files -->
    <link rel="stylesheet" href="assets/css/variables.css">
    <link rel="stylesheet" href="assets/css/reset.css">
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/utilities.css">
    <link rel="stylesheet" href="assets/css/forms.css">
    <link rel="stylesheet" href="assets/css/buttons.css">
    <link rel="stylesheet" href="assets/css/cards.css">
    <link rel="stylesheet" href="assets/css/badges.css">
    <link rel="stylesheet" href="assets/css/dark-mode.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link rel="stylesheet" href="assets/css/modals.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .user-preview-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 20px;
        }
        
        .profile-header {
            display: flex;
            align-items: center;
            gap: 2rem;
            margin-bottom: 2rem;
            padding: 2rem;
            background: #fff;
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
        }
        
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: var(--color-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
            font-weight: bold;
            flex-shrink: 0;
            overflow: hidden;
        }
        
        .profile-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .profile-info h1 {
            margin-bottom: 0.5rem;
            color: var(--grey-900);
        }
        
        .profile-role {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            background: var(--color-primary);
            color: white;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .profile-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: #fff;
            padding: 1.5rem;
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            text-align: center;
            transition: var(--transition);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--color-primary);
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: var(--grey-600);
            font-size: 0.9rem;
        }
        
        .profile-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }
        
        .profile-section {
            background: #fff;
            padding: 1.5rem;
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
        }
        
        .section-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid var(--grey-200);
            color: var(--grey-800);
        }
        
        .info-grid {
            display: grid;
            gap: 1rem;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--grey-100);
        }
        
        .info-label {
            font-weight: 600;
            color: var(--grey-700);
            min-width: 120px;
        }
        
        .info-value {
            color: var(--grey-800);
            flex: 1;
        }
        
        .profile-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }
        
        .membership-status {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: var(--radius);
            font-weight: 600;
            margin-top: 0.5rem;
        }
        
        .status-active {
            background: rgba(34, 197, 94, 0.1);
            color: #16a34a;
        }
        
        .status-inactive {
            background: rgba(239, 68, 68, 0.1);
            color: #dc2626;
        }
        
        .status-suspended {
            background: rgba(245, 158, 11, 0.1);
            color: #d97706;
        }
        
        .limited-access-notice {
            background: var(--warning);
            color: var(--grey-900);
            padding: 1rem;
            border-radius: var(--radius);
            margin: 2rem 0;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .admin-actions-section {
            margin-top: 2rem;
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: var(--grey-500);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--grey-300);
        }
        
        /* Modal Styles for Admin Actions */
        .admin-modal-content {
            max-width: 500px;
        }
        
        .modal-form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 1.5rem;
        }
        
        .danger-zone {
            border: 1px solid var(--error);
            border-radius: var(--radius);
            padding: 1.5rem;
            margin-top: 2rem;
        }
        
        .danger-zone h4 {
            color: var(--error);
            margin-bottom: 1rem;
        }
        
        @media (max-width: 768px) {
            .profile-content {
                grid-template-columns: 1fr;
            }
            
            .profile-header {
                flex-direction: column;
                text-align: center;
            }
            
            .profile-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .profile-actions {
                justify-content: center;
            }
            
            .info-item {
                flex-direction: column;
                gap: 0.25rem;
            }
            
            .info-label {
                min-width: auto;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
        
        @media (max-width: 480px) {
            .profile-stats {
                grid-template-columns: 1fr;
            }
        }
        
        [data-theme="dark"] .profile-header,
        [data-theme="dark"] .stat-card,
        [data-theme="dark"] .profile-section {
            background: var(--dark-2);
        }
        
        [data-theme="dark"] .section-title {
            color: var(--grey-100);
            border-bottom-color: var(--dark-3);
        }
        
        [data-theme="dark"] .info-item {
            border-bottom-color: var(--dark-3);
        }
        
        [data-theme="dark"] .info-label {
            color: var(--grey-300);
        }
        
        [data-theme="dark"] .info-value {
            color: var(--grey-200);
        }
        
        [data-theme="dark"] .limited-access-notice {
            background: rgba(234, 179, 8, 0.2);
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="user-preview-container">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="profile-avatar">
                <?php if ($user['profile_pic']): ?>
                    <img src="<?php echo htmlspecialchars($user['profile_pic']); ?>" alt="Profile Picture">
                <?php else: ?>
                    <?php echo strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1)); ?>
                <?php endif; ?>
            </div>
            
            <div class="profile-info">
                <h1><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h1>
                <div class="profile-role"><?php echo ucfirst($user['role_name']); ?> Member</div>
                
                <div class="membership-status <?php echo 'status-' . $user['membership_status']; ?>">
                    <i class="fas fa-<?php echo $user['membership_status'] === 'active' ? 'check-circle' : ($user['membership_status'] === 'suspended' ? 'exclamation-triangle' : 'times-circle'); ?>"></i>
                    <?php echo ucfirst($user['membership_status']); ?> Member
                </div>
                
                <?php if ($user_id == $_SESSION['user_id']): ?>
                    <p style="color: var(--grey-600); margin-top: 1rem;">
                        <i class="fas fa-info-circle"></i> This is your profile
                    </p>
                <?php endif; ?>
                
                <!-- Admin Actions -->
                <?php if ($is_admin && $user_id != $_SESSION['user_id']): ?>
                <div class="profile-actions">
                    <button class="btn btn-primary" onclick="openEditModal()">
                        <i class="fas fa-edit"></i> Edit User
                    </button>
                    
                    <?php if ($user['membership_status'] === 'active'): ?>
                        <button class="btn btn-warning" onclick="openSuspendModal()">
                            <i class="fas fa-pause"></i> Suspend User
                        </button>
                    <?php elseif ($user['membership_status'] === 'suspended'): ?>
                        <button class="btn btn-success" onclick="openActivateModal()">
                            <i class="fas fa-play"></i> Activate User
                        </button>
                    <?php endif; ?>
                    
                    <button class="btn btn-danger" onclick="openDeleteModal()">
                        <i class="fas fa-trash"></i> Delete User
                    </button>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Statistics Cards -->
        <?php if ($is_admin || $user_id == $_SESSION['user_id']): ?>
        <div class="profile-stats">
            <div class="stat-card">
                <div class="stat-value"><?php echo $user_stats['borrowed_books'] ?? 0; ?></div>
                <div class="stat-label">Books Borrowed</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo $user_stats['reserved_books'] ?? 0; ?></div>
                <div class="stat-label">Books Reserved</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo $user_stats['overdue_books'] ?? 0; ?></div>
                <div class="stat-label">Overdue Books</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">$<?php echo number_format($user_stats['total_fines'] ?? 0, 2); ?></div>
                <div class="stat-label">Outstanding Fines</div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Profile Content -->
        <div class="profile-content">
            <!-- Personal Information -->
            <div class="profile-section">
                <h2 class="section-title">Personal Information</h2>
                <div class="info-grid">
                    <?php if ($is_admin): ?>
                        <!-- Full details for admin -->
                        <div class="info-item">
                            <span class="info-label">Username:</span>
                            <span class="info-value"><?php echo htmlspecialchars($user['username']); ?></span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Email:</span>
                            <span class="info-value"><?php echo htmlspecialchars($user['email']); ?></span>
                        </div>
                        
                        <?php if (!empty($user['school_id'])): ?>
                        <div class="info-item">
                            <span class="info-label">School ID:</span>
                            <span class="info-value"><?php echo htmlspecialchars($user['school_id']); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($user['phone'])): ?>
                        <div class="info-item">
                            <span class="info-label">Phone:</span>
                            <span class="info-value"><?php echo htmlspecialchars($user['phone']); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <div class="info-item">
                            <span class="info-label">Access Level:</span>
                            <span class="info-value"><?php echo $user['access_level']; ?></span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Member Since:</span>
                            <span class="info-value"><?php echo date('F j, Y', strtotime($user['created_at'])); ?></span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Last Login:</span>
                            <span class="info-value">
                                <?php echo $user['last_login'] ? date('F j, Y g:i A', strtotime($user['last_login'])) : 'Never'; ?>
                            </span>
                        </div>
                        
                    <?php else: ?>
                        <!-- Limited details for regular users -->
                        <div class="info-item">
                            <span class="info-label">Role:</span>
                            <span class="info-value"><?php echo ucfirst($user['role_name']); ?></span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Member Since:</span>
                            <span class="info-value"><?php echo date('F j, Y', strtotime($user['created_at'])); ?></span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Status:</span>
                            <span class="info-value"><?php echo ucfirst($user['membership_status']); ?></span>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Additional Info for Admin -->
                <?php if ($is_admin && (!empty($user['bio']) || !empty($user['location']) || !empty($user['website']))): ?>
                <div style="margin-top: 1.5rem;">
                    <h3 style="margin-bottom: 0.5rem; color: var(--grey-700);">Additional Information</h3>
                    <?php if (!empty($user['bio'])): ?>
                        <p style="color: var(--grey-600); line-height: 1.6; margin-bottom: 1rem;">
                            <strong>Bio:</strong> <?php echo nl2br(htmlspecialchars($user['bio'])); ?>
                        </p>
                    <?php endif; ?>
                    
                    <?php if (!empty($user['location'])): ?>
                        <p style="color: var(--grey-600); margin-bottom: 0.5rem;">
                            <strong>Location:</strong> <?php echo htmlspecialchars($user['location']); ?>
                        </p>
                    <?php endif; ?>
                    
                    <?php if (!empty($user['website'])): ?>
                        <p style="color: var(--grey-600);">
                            <strong>Website:</strong> 
                            <a href="<?php echo htmlspecialchars($user['website']); ?>" target="_blank">
                                <?php echo htmlspecialchars($user['website']); ?>
                            </a>
                        </p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Activity Section -->
            <div class="profile-section">
                <h2 class="section-title">Account Information</h2>
                
                <?php if (!$is_admin && $user_id != $_SESSION['user_id']): ?>
                <div class="limited-access-notice">
                    <i class="fas fa-info-circle"></i>
                    <div>
                        <strong>Limited Profile View</strong>
                        <p style="margin: 0.5rem 0 0 0; font-size: 0.9rem;">
                            Contact library staff for more information about this user.
                        </p>
                    </div>
                </div>
                <?php else: ?>
                    <div class="info-grid">
                        <div class="info-item">
                            <span class="info-label">Account Status:</span>
                            <span class="info-value">
                                <span class="membership-status <?php echo 'status-' . $user['membership_status']; ?>" style="margin: 0;">
                                    <i class="fas fa-<?php echo $user['membership_status'] === 'active' ? 'check-circle' : ($user['membership_status'] === 'suspended' ? 'exclamation-triangle' : 'times-circle'); ?>"></i>
                                    <?php echo ucfirst($user['membership_status']); ?>
                                </span>
                            </span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Role:</span>
                            <span class="info-value"><?php echo ucfirst($user['role_name']); ?></span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">ID Verified:</span>
                            <span class="info-value">
                                <?php echo $user['id_verified'] ? 
                                    '<span style="color: #16a34a;"><i class="fas fa-check-circle"></i> Verified</span>' : 
                                    '<span style="color: #dc2626;"><i class="fas fa-times-circle"></i> Not Verified</span>'; ?>
                            </span>
                        </div>
                        
                        <?php if ($user['membership_expiry']): ?>
                        <div class="info-item">
                            <span class="info-label">Membership Expires:</span>
                            <span class="info-value"><?php echo date('F j, Y', strtotime($user['membership_expiry'])); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Admin Action Modals -->
    <?php if ($is_admin && $user_id != $_SESSION['user_id']): ?>
    
    <!-- Edit User Modal -->
    <div class="modal-overlay" id="editModal">
        <div class="modal admin-modal-content">
            <div class="modal-header">
                <h3>Edit User: <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h3>
                <button class="modal-close" onclick="closeEditModal()">&times;</button>
            </div>
            <div class="modal-body">
                <form id="editUserForm" class="modal-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="edit_first_name">First Name</label>
                            <input type="text" class="input" id="edit_first_name" name="first_name" 
                                   value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="edit_last_name">Last Name</label>
                            <input type="text" class="input" id="edit_last_name" name="last_name" 
                                   value="<?php echo htmlspecialchars($user['last_name']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="edit_email">Email Address</label>
                        <input type="email" class="input" id="edit_email" name="email" 
                               value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="edit_role">Role</label>
                        <select class="select" id="edit_role" name="role_id" required>
                            <option value="1" <?php echo $user['role_id'] == 1 ? 'selected' : ''; ?>>Admin</option>
                            <option value="2" <?php echo $user['role_id'] == 2 ? 'selected' : ''; ?>>Librarian</option>
                            <option value="3" <?php echo $user['role_id'] == 3 ? 'selected' : ''; ?>>Teacher</option>
                            <option value="4" <?php echo $user['role_id'] == 4 ? 'selected' : ''; ?>>Student</option>
                            <option value="5" <?php echo $user['role_id'] == 5 ? 'selected' : ''; ?>>Regular</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="edit_status">Membership Status</label>
                        <select class="select" id="edit_status" name="membership_status" required>
                            <option value="active" <?php echo $user['membership_status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="suspended" <?php echo $user['membership_status'] == 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                            <option value="inactive" <?php echo $user['membership_status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update User
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Suspend User Modal -->
    <div class="modal-overlay" id="suspendModal">
        <div class="modal admin-modal-content">
            <div class="modal-header">
                <h3>Suspend User</h3>
                <button class="modal-close" onclick="closeSuspendModal()">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to suspend <strong><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></strong>?</p>
                <p style="color: var(--grey-600); font-size: 0.9rem; margin-top: 0.5rem;">
                    The user will not be able to access the system until their account is reactivated.
                </p>
                
                <form id="suspendUserForm" class="modal-form">
                    <div class="form-group">
                        <label class="form-label" for="suspend_reason">Reason for Suspension</label>
                        <textarea class="textarea" id="suspend_reason" name="reason" 
                                  placeholder="Optional: Enter reason for suspension..." rows="3"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" class="btn btn-secondary" onclick="closeSuspendModal()">Cancel</button>
                        <button type="submit" class="btn btn-warning">
                            <i class="fas fa-pause"></i> Suspend User
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Activate User Modal -->
    <div class="modal-overlay" id="activateModal">
        <div class="modal admin-modal-content">
            <div class="modal-header">
                <h3>Activate User</h3>
                <button class="modal-close" onclick="closeActivateModal()">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to activate <strong><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></strong>?</p>
                <p style="color: var(--grey-600); font-size: 0.9rem; margin-top: 0.5rem;">
                    The user will be able to access the system immediately.
                </p>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeActivateModal()">Cancel</button>
                    <button type="button" class="btn btn-success" onclick="activateUser()">
                        <i class="fas fa-play"></i> Activate User
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete User Modal -->
    <div class="modal-overlay" id="deleteModal">
        <div class="modal admin-modal-content">
            <div class="modal-header">
                <h3>Delete User</h3>
                <button class="modal-close" onclick="closeDeleteModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="danger-zone">
                    <h4><i class="fas fa-exclamation-triangle"></i> Danger Zone</h4>
                    <p>This action cannot be undone. This will permanently delete the user account and all associated data.</p>
                </div>
                
                <p style="margin-top: 1.5rem;">Are you sure you want to delete <strong><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></strong>?</p>
                
                <form id="deleteUserForm" class="modal-form">
                    <div class="form-group">
                        <label class="form-label" for="delete_reason">Reason for Deletion</label>
                        <textarea class="textarea" id="delete_reason" name="reason" 
                                  placeholder="Enter reason for deletion..." rows="3" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" name="confirm_delete" required>
                            I understand that this action cannot be undone
                        </label>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">Cancel</button>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Delete User Permanently
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php endif; ?>

    <script>
    // Modal Functions
    function openEditModal() {
        document.getElementById('editModal').classList.add('active');
    }
    
    function closeEditModal() {
        document.getElementById('editModal').classList.remove('active');
    }
    
    function openSuspendModal() {
        document.getElementById('suspendModal').classList.add('active');
    }
    
    function closeSuspendModal() {
        document.getElementById('suspendModal').classList.remove('active');
    }
    
    function openActivateModal() {
        document.getElementById('activateModal').classList.add('active');
    }
    
    function closeActivateModal() {
        document.getElementById('activateModal').classList.remove('active');
    }
    
    function openDeleteModal() {
        document.getElementById('deleteModal').classList.add('active');
    }
    
    function closeDeleteModal() {
        document.getElementById('deleteModal').classList.remove('active');
    }
    
    // Close modals when clicking outside
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal-overlay')) {
            e.target.classList.remove('active');
        }
    });
    
    // Form submissions
    document.addEventListener('DOMContentLoaded', function() {
        // Edit User Form
        const editForm = document.getElementById('editUserForm');
        if (editForm) {
            editForm.addEventListener('submit', function(e) {
                e.preventDefault();
                // Implement edit functionality
                alert('Edit functionality would be implemented here.');
                closeEditModal();
            });
        }
        
        // Suspend User Form
        const suspendForm = document.getElementById('suspendUserForm');
        if (suspendForm) {
            suspendForm.addEventListener('submit', function(e) {
                e.preventDefault();
                // Implement suspend functionality
                alert('Suspend functionality would be implemented here.');
                closeSuspendModal();
            });
        }
        
        // Delete User Form
        const deleteForm = document.getElementById('deleteUserForm');
        if (deleteForm) {
            deleteForm.addEventListener('submit', function(e) {
                e.preventDefault();
                // Implement delete functionality
                alert('Delete functionality would be implemented here.');
                closeDeleteModal();
            });
        }
    });
    
    // Activate User Function
    function activateUser() {
        // Implement activate functionality
        alert('Activate functionality would be implemented here.');
        closeActivateModal();
    }
    
    // Add reveal animations
    document.addEventListener('DOMContentLoaded', function() {
        const elements = document.querySelectorAll('[data-reveal]');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                }
            });
        }, { threshold: 0.1 });
        
        elements.forEach(element => {
            observer.observe(element);
        });
    });
    </script>
</body>
</html>