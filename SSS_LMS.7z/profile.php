<?php
require_once 'includes/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Get user data
$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare("
    SELECT u.*, ur.role_name 
    FROM users u 
    JOIN user_roles ur ON u.role_id = ur.id 
    WHERE u.id = ?
");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("User not found");
}

// Handle profile updates
$updateSuccess = false;
$updateError = '';

// Handle profile picture upload
$uploadSuccess = false;
$uploadError = '';

// Create uploads directory if it doesn't exist
$uploadDir = __DIR__ . '/uploads/profile_pics/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if it's a profile picture upload
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] !== UPLOAD_ERR_NO_FILE) {
        $profilePic = $_FILES['profile_pic'];
        
        // Validate file upload
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxFileSize = 5 * 1024 * 1024; // 5MB
        
        if ($profilePic['error'] !== UPLOAD_ERR_OK) {
            $uploadError = "File upload error: " . $profilePic['error'];
        } elseif ($profilePic['size'] > $maxFileSize) {
            $uploadError = "File too large. Maximum size is 5MB.";
        } else {
            $fileInfo = getimagesize($profilePic['tmp_name']);
            if (!$fileInfo || !in_array($fileInfo['mime'], $allowedTypes)) {
                $uploadError = "Invalid file type. Only JPG, PNG, GIF, and WebP images are allowed.";
            } else {
                // Generate unique filename
                $fileExtension = pathinfo($profilePic['name'], PATHINFO_EXTENSION);
                $fileName = 'profile_' . $userId . '_' . time() . '.' . $fileExtension;
                $filePath = $uploadDir . $fileName;
                
                // Resize and save image
                if (resizeAndSaveImage($profilePic['tmp_name'], $filePath, 200, 200)) {
                    // Delete old profile picture if exists
                    if (!empty($user['profile_pic']) && file_exists(__DIR__ . $user['profile_pic'])) {
                        unlink(__DIR__ . $user['profile_pic']);
                    }
                    
                    // Update database with new profile picture path
                    $webPath = '/uploads/profile_pics/' . $fileName;
                    $stmt = $pdo->prepare("UPDATE users SET profile_pic = ? WHERE id = ?");
                    if ($stmt->execute([$webPath, $userId])) {
                        $uploadSuccess = true;
                        $user['profile_pic'] = $webPath;
                    } else {
                        $uploadError = "Failed to update profile picture in database.";
                    }
                } else {
                    $uploadError = "Failed to process image. Please try another image.";
                }
            }
        }
    } else {
        // Handle regular profile update
        $firstName = trim($_POST['first_name'] ?? '');
        $lastName = trim($_POST['last_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        $location = trim($_POST['location'] ?? '');
        $website = trim($_POST['website'] ?? '');
        
        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $updateError = "Please enter a valid email address";
        } else {
            // Check if email already exists (excluding current user)
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $userId]);
            if ($stmt->fetch()) {
                $updateError = "Email address is already in use";
            } else {
                // Update user profile
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET first_name = ?, last_name = ?, email = ?, phone = ?, bio = ?, location = ?, website = ?, updated_at = CURRENT_TIMESTAMP 
                    WHERE id = ?
                ");
                
                if ($stmt->execute([$firstName, $lastName, $email, $phone, $bio, $location, $website, $userId])) {
                    $updateSuccess = true;
                    // Refresh user data
                    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                    $stmt->execute([$userId]);
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                } else {
                    $updateError = "Failed to update profile. Please try again.";
                }
            }
        }
    }
}

// Image resizing function
function resizeAndSaveImage($sourcePath, $destinationPath, $maxWidth, $maxHeight) {
    $imageInfo = getimagesize($sourcePath);
    if (!$imageInfo) return false;
    
    list($originalWidth, $originalHeight, $type) = $imageInfo;
    
    // Calculate new dimensions
    $ratio = $originalWidth / $originalHeight;
    if ($maxWidth / $maxHeight > $ratio) {
        $newWidth = $maxHeight * $ratio;
        $newHeight = $maxHeight;
    } else {
        $newWidth = $maxWidth;
        $newHeight = $maxWidth / $ratio;
    }
    
    // Create image resource based on type
    switch ($type) {
        case IMAGETYPE_JPEG:
            $sourceImage = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $sourceImage = imagecreatefrompng($sourcePath);
            break;
        case IMAGETYPE_GIF:
            $sourceImage = imagecreatefromgif($sourcePath);
            break;
        case IMAGETYPE_WEBP:
            $sourceImage = imagecreatefromwebp($sourcePath);
            break;
        default:
            return false;
    }
    
    if (!$sourceImage) return false;
    
    // Create new image
    $newImage = imagecreatetruecolor($newWidth, $newHeight);
    
    // Preserve transparency for PNG and GIF
    if ($type == IMAGETYPE_PNG || $type == IMAGETYPE_GIF) {
        imagecolortransparent($newImage, imagecolorallocatealpha($newImage, 0, 0, 0, 127));
        imagealphablending($newImage, false);
        imagesavealpha($newImage, true);
    }
    
    // Resize image
    imagecopyresampled($newImage, $sourceImage, 0, 0, 0, 0, $newWidth, $newHeight, $originalWidth, $originalHeight);
    
    // Save image based on type
    switch ($type) {
        case IMAGETYPE_JPEG:
            $result = imagejpeg($newImage, $destinationPath, 90);
            break;
        case IMAGETYPE_PNG:
            $result = imagepng($newImage, $destinationPath, 9);
            break;
        case IMAGETYPE_GIF:
            $result = imagegif($newImage, $destinationPath);
            break;
        case IMAGETYPE_WEBP:
            $result = imagewebp($newImage, $destinationPath, 90);
            break;
        default:
            $result = false;
    }
    
    // Free memory
    imagedestroy($sourceImage);
    imagedestroy($newImage);
    
    return $result;
}

// Get user statistics
$stats = [
    'borrowed_books' => 0,
    'reserved_books' => 0,
    'overdue_books' => 0,
    'total_fines' => 0
];

// Borrowed books count
$stmt = $pdo->prepare("
    SELECT COUNT(*) as count 
    FROM borrow_transactions 
    WHERE user_id = ? AND status IN ('active', 'overdue')
");
$stmt->execute([$userId]);
$stats['borrowed_books'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Reserved books count
$stmt = $pdo->prepare("
    SELECT COUNT(*) as count 
    FROM borrow_transactions 
    WHERE user_id = ? AND status = 'pending' AND transaction_type = 'reserve'
");
$stmt->execute([$userId]);
$stats['reserved_books'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Overdue books count
$stmt = $pdo->prepare("
    SELECT COUNT(*) as count 
    FROM borrow_transactions 
    WHERE user_id = ? AND status = 'overdue'
");
$stmt->execute([$userId]);
$stats['overdue_books'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Total fines
$stmt = $pdo->prepare("
    SELECT COALESCE(SUM(amount), 0) as total 
    FROM fines 
    WHERE user_id = ? AND status = 'unpaid'
");
$stmt->execute([$userId]);
$stats['total_fines'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Sabian Library</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>
    
    <div class="profile-container">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="profile-avatar-container">
                <div class="profile-avatar" onclick="openUploadModal()">
                    <?php if (!empty($user['profile_pic'])): ?>
                        <img src="<?php echo htmlspecialchars($user['profile_pic']); ?>" alt="Profile Picture">
                    <?php else: ?>
                        <?php echo strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1)); ?>
                    <?php endif; ?>
                </div>
                <div class="avatar-upload-overlay" onclick="openUploadModal()">
                    <i class="fas fa-camera"></i>
                </div>
            </div>
            
            <div class="profile-info">
                <h1><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h1>
                <div class="profile-role"><?php echo htmlspecialchars(ucfirst($user['role_name'])); ?></div>
                
                <?php if (!empty($user['school_id'])): ?>
                    <p><strong>School ID:</strong> <?php echo htmlspecialchars($user['school_id']); ?></p>
                <?php endif; ?>
                
                <div class="membership-status <?php echo 'status-' . $user['membership_status']; ?>">
                    <i class="fas fa-<?php echo $user['membership_status'] === 'active' ? 'check-circle' : ($user['membership_status'] === 'suspended' ? 'exclamation-triangle' : 'times-circle'); ?>"></i>
                    <?php echo ucfirst($user['membership_status']); ?> Member
                </div>
                
                <div class="profile-actions">
                    <button class="btn btn-primary" onclick="document.getElementById('editProfileForm').scrollIntoView({behavior: 'smooth'})">
                        <i class="fas fa-edit"></i> Edit Profile
                    </button>
                    <button class="btn btn-outline" onclick="changePassword()">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                    <button class="btn btn-secondary" onclick="openUploadModal()">
                        <i class="fas fa-camera"></i> Change Photo
                    </button>
                </div>
            </div>
        </div>

        <!-- Upload Success/Error Messages -->
        <?php if ($uploadSuccess): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> Profile picture updated successfully!
            </div>
        <?php endif; ?>
        
        <?php if ($uploadError): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($uploadError); ?>
            </div>
        <?php endif; ?>
        
        <!-- Statistics Cards -->
        <div class="profile-stats">
            <div class="stat-card">
                <div class="stat-value"><?php echo $stats['borrowed_books']; ?></div>
                <div class="stat-label">Books Borrowed</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo $stats['reserved_books']; ?></div>
                <div class="stat-label">Books Reserved</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo $stats['overdue_books']; ?></div>
                <div class="stat-label">Overdue Books</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">$<?php echo number_format($stats['total_fines'], 2); ?></div>
                <div class="stat-label">Outstanding Fines</div>
            </div>
        </div>
        
        <!-- Profile Content -->
        <div class="profile-content">
            <!-- Personal Information -->
            <div class="profile-section">
                <h2 class="section-title">Personal Information</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">Full Name:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Email:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['email']); ?></span>
                    </div>
                    <?php if (!empty($user['phone'])): ?>
                    <div class="info-item">
                        <span class="info-label">Phone:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['phone']); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($user['age'])): ?>
                    <div class="info-item">
                        <span class="info-label">Age:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['age']); ?> years</span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($user['sex'])): ?>
                    <div class="info-item">
                        <span class="info-label">Gender:</span>
                        <span class="info-value"><?php echo htmlspecialchars(ucfirst($user['sex'])); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($user['location'])): ?>
                    <div class="info-item">
                        <span class="info-label">Location:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['location']); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($user['website'])): ?>
                    <div class="info-item">
                        <span class="info-label">Website:</span>
                        <span class="info-value">
                            <a href="<?php echo htmlspecialchars($user['website']); ?>" target="_blank">
                                <?php echo htmlspecialchars($user['website']); ?>
                            </a>
                        </span>
                    </div>
                    <?php endif; ?>
                    <div class="info-item">
                        <span class="info-label">Member Since:</span>
                        <span class="info-value"><?php echo date('F j, Y', strtotime($user['created_at'])); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Last Login:</span>
                        <span class="info-value">
                            <?php echo $user['last_login'] ? date('F j, Y g:i A', strtotime($user['last_login'])) : 'Never'; ?>
                        </span>
                    </div>
                </div>
                
                <?php if (!empty($user['bio'])): ?>
                <div style="margin-top: 1.5rem;">
                    <h3 style="margin-bottom: 0.5rem; color: var(--grey-700);">About Me</h3>
                    <p style="color: var(--grey-600); line-height: 1.6;"><?php echo nl2br(htmlspecialchars($user['bio'])); ?></p>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Edit Profile Form -->
            <div class="profile-section" id="editProfileForm">
                <h2 class="section-title">Edit Profile</h2>
                
                <?php if ($updateSuccess): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> Profile updated successfully!
                    </div>
                <?php endif; ?>
                
                <?php if ($updateError): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($updateError); ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="first_name">First Name</label>
                            <input type="text" class="input" id="first_name" name="first_name" 
                                   value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="last_name">Last Name</label>
                            <input type="text" class="input" id="last_name" name="last_name" 
                                   value="<?php echo htmlspecialchars($user['last_name']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="email">Email Address</label>
                        <input type="email" class="input" id="email" name="email" 
                               value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="phone">Phone Number</label>
                        <input type="tel" class="input" id="phone" name="phone" 
                               value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="location">Location</label>
                        <input type="text" class="input" id="location" name="location" 
                               value="<?php echo htmlspecialchars($user['location'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="website">Website</label>
                        <input type="url" class="input" id="website" name="website" 
                               value="<?php echo htmlspecialchars($user['website'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="bio">Bio</label>
                        <textarea class="textarea" id="bio" name="bio" rows="4" 
                                  placeholder="Tell us a little about yourself..."><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Profile
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Recent Activity Section -->
        <div class="profile-section" style="margin-top: 2rem;">
            <h2 class="section-title">Recent Activity</h2>
            
            <?php
            // Get recent borrow transactions
            $stmt = $pdo->prepare("
                SELECT bt.*, b.title, b.author 
                FROM borrow_transactions bt 
                JOIN books b ON bt.book_id = b.id 
                WHERE bt.user_id = ? 
                ORDER BY bt.created_at DESC 
                LIMIT 5
            ");
            $stmt->execute([$userId]);
            $recentActivity = $stmt->fetchAll(PDO::FETCH_ASSOC);
            ?>
            
            <?php if (empty($recentActivity)): ?>
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <h3>No Recent Activity</h3>
                    <p>Your borrowing history will appear here.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Book</th>
                                <th>Type</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentActivity as $activity): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($activity['title']); ?></strong><br>
                                        <small class="text-muted">by <?php echo htmlspecialchars($activity['author']); ?></small>
                                    </td>
                                    <td>
                                        <?php 
                                        $typeLabels = [
                                            'borrow' => 'Borrow',
                                            'reserve' => 'Reservation',
                                            'renew' => 'Renewal'
                                        ];
                                        echo $typeLabels[$activity['transaction_type']] ?? $activity['transaction_type'];
                                        ?>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($activity['created_at'])); ?></td>
                                    <td>
                                        <?php 
                                        $statusClasses = [
                                            'pending' => 'badge badge-issued',
                                            'approved' => 'badge badge-available',
                                            'active' => 'badge badge-available',
                                            'returned' => 'badge badge-reserved',
                                            'overdue' => 'badge badge-lost',
                                            'cancelled' => 'badge badge-lost'
                                        ];
                                        $statusClass = $statusClasses[$activity['status']] ?? 'badge badge-reserved';
                                        ?>
                                        <span class="<?php echo $statusClass; ?>">
                                            <?php echo ucfirst($activity['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div style="text-align: center; margin-top: 1rem;">
                    <a href="/borrowing/history.php" class="btn btn-outline">
                        <i class="fas fa-list"></i> View Full History
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Profile Picture Upload Modal -->
    <div class="upload-modal" id="uploadModal">
        <div class="upload-modal-content">
            <h2 style="margin-bottom: 1.5rem;">Update Profile Picture</h2>
            
            <form id="uploadForm" method="POST" action="" enctype="multipart/form-data">
                <div class="form-group">
                    <label class="form-label" for="profile_pic">Choose Image</label>
                    <input type="file" class="input" id="profile_pic" name="profile_pic" 
                           accept="image/jpeg,image/png,image/gif,image/webp" required>
                    <small style="color: var(--grey-500); display: block; margin-top: 0.5rem;">
                        Supported formats: JPG, PNG, GIF, WebP. Max size: 5MB.
                    </small>
                </div>
                
                <div id="imagePreviewContainer" style="display: none;">
                    <img id="imagePreview" class="upload-preview" alt="Image Preview">
                </div>
                
                <div class="upload-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeUploadModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="uploadButton" disabled>
                        <i class="fas fa-upload"></i> Upload Photo
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function changePassword() {
            // This would typically open a modal or redirect to password change page
            alert('Password change functionality would be implemented here.');
        }
        
        function openUploadModal() {
            document.getElementById('uploadModal').classList.add('active');
        }
        
        function closeUploadModal() {
            document.getElementById('uploadModal').classList.remove('active');
            document.getElementById('uploadForm').reset();
            document.getElementById('imagePreviewContainer').style.display = 'none';
            document.getElementById('uploadButton').disabled = true;
        }
        
        // Image preview functionality
        document.getElementById('profile_pic').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const preview = document.getElementById('imagePreview');
            const previewContainer = document.getElementById('imagePreviewContainer');
            const uploadButton = document.getElementById('uploadButton');
            
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    previewContainer.style.display = 'block';
                    uploadButton.disabled = false;
                }
                
                reader.readAsDataURL(file);
            } else {
                previewContainer.style.display = 'none';
                uploadButton.disabled = true;
            }
        });
        
        // Close modal when clicking outside
        document.getElementById('uploadModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeUploadModal();
            }
        });
        
        // Add reveal animations
        document.addEventListener('DOMContentLoaded', function() {
            const elements = document.querySelectorAll('[data-reveal]');
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('revealed');
                    }
                });
            }, { threshold: 0.1 });
            
            elements.forEach(element => {
                observer.observe(element);
            });
        });
    </script>
</body>
</html>